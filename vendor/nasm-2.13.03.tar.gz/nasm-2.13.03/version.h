#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      13
#define NASM_SUBMINOR_VER   3
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x020d0300
#define NASM_VER            "2.13.03"
#endif /* NASM_VERSION_H */
