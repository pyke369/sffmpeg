// derived from cttmetrics_sample.cpp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cttmetrics.h>

#define MAX_GPU_FREQ_SKYLAKE 1100.0
#define MAX_GPU_FREQ_HASWELL 1000.0

int main(int argc, char *argv[])
{
    cttStatus status = CTT_ERR_NONE;
    cttMetric metrics_ids[] = {CTT_USAGE_RENDER, CTT_USAGE_VIDEO, CTT_USAGE_VIDEO_ENHANCEMENT, CTT_AVG_GT_FREQ, CTT_USAGE_VIDEO2};
    unsigned int metric_cnt = sizeof(metrics_ids)/sizeof(metrics_ids[0]);

    unsigned int num_samples = 100;
    unsigned int period_ms = 500;

    if (1 < argc && NULL != argv[1])
    {
        num_samples = atoi(argv[1]);
    }

    if (2 < argc && NULL != argv[2])
    {
        period_ms = atoi(argv[2]);
    }

    status = CTTMetrics_Init(NULL);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to initialize metrics monitor, error code %d\n", (int)status);
        return 1;
    }

    unsigned int metric_all_cnt = 0;
    status = CTTMetrics_GetMetricCount(&metric_all_cnt);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to get number of metrics available, error code %d\n", (int)status);
        return 1;
    }

    cttMetric metric_all_ids[CTT_MAX_METRIC_COUNT] = {CTT_WRONG_METRIC_ID};
    status = CTTMetrics_GetMetricInfo(metric_all_cnt, metric_all_ids);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to get metrics info, error code %d\n", (int)status);
        return 1;
    }

    unsigned int i;
    bool isVideo2 = false;
    for (i = 0; i < metric_all_cnt; ++i)
    {
        if (CTT_USAGE_VIDEO2 == metric_all_ids[i])
          isVideo2 = true;
    }

    if (false == isVideo2)
        metric_cnt = metric_cnt - 1; // exclude video2 usage metric

    bool isFreq = false;
    for (i = 0; i < metric_all_cnt; ++i)
    {
        if (CTT_AVG_GT_FREQ == metric_all_ids[i])
          isFreq = true;
    }

    if (false == isFreq)
        metric_cnt = metric_cnt - 1; // exclude average frequency metric

    status = CTTMetrics_Subscribe(metric_cnt, metrics_ids);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to subscribe for metrics, error code %d\n", (int)status);
        return 1;
    }

    status = CTTMetrics_SetSampleCount(num_samples);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to set number of samples, error code %d\n", (int)status);
        return 1;
    }

    status = CTTMetrics_SetSamplePeriod(period_ms);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to set measure interval, error code %d\n", (int)status);
        return 1;
    }

    float metric_values[metric_cnt];
    memset(metric_values, 0, (size_t)metric_cnt * sizeof(float));

    status = CTTMetrics_GetValue(metric_cnt, metric_values);
    if (CTT_ERR_NONE != status)
    {
        fprintf(stderr, "ERROR: Failed to get metrics, error code %d\n", status);
        return 1;
    }

    printf("RENDER=%3.2f VIDEO=%3.2f VIDEO_E=%3.2f", metric_values[0], metric_values[1], metric_values[2]);

    if (true == isVideo2)
        printf(" VIDEO2=%3.2f", metric_values[4]);

    if (true == isFreq)
    {
        FILE* cpuinfo;
        char* line;
        size_t len = 0;
        ssize_t read;
        int max_freq;

        cpuinfo = popen("grep \"model name\" /proc/cpuinfo | head -n 1", "r");
        if (cpuinfo)
        {
            if (getline(&line, &len, cpuinfo) != -1)
            {
                if (strstr(line, "i7-4860EQ") || strstr(line, "E3-1284L v3"))
                    max_freq = MAX_GPU_FREQ_HASWELL;
                else if (strstr(line, "E3-1585L v5"))
                    max_freq = MAX_GPU_FREQ_SKYLAKE;
                else
                    max_freq = 0;

                if (max_freq)
                    printf(" GT_Freq=%4.2f", 100.0*metric_values[3]/max_freq);
            }

            fclose(cpuinfo);
        }
    }

    printf("\n");

    CTTMetrics_Close();

    return 0;
}
