var struct__ni__nvme__id__power__state =
[
    [ "aui8Rsvd23", "struct__ni__nvme__id__power__state.html#affcbe5447aef2de3b43c5fcbfc2da6ca", null ],
    [ "ui16ActivePower", "struct__ni__nvme__id__power__state.html#a0e2198436cc6197a92c4e9da481277a7", null ],
    [ "ui16IdlePower", "struct__ni__nvme__id__power__state.html#ae71bb513e7981aeacf87ec6a26e96f5d", null ],
    [ "ui16MaxPower", "struct__ni__nvme__id__power__state.html#a11c3ed9aea0c1454fa8360b7fddb586b", null ],
    [ "ui32EntryLat", "struct__ni__nvme__id__power__state.html#a06021ca920093dec51a6c35875842251", null ],
    [ "ui32ExitLat", "struct__ni__nvme__id__power__state.html#a32dd91cd98cdbff7725b6cf5fce53cf8", null ],
    [ "ui8ActiveWorkScale", "struct__ni__nvme__id__power__state.html#adc02ca520aba529c9da2dcd056dbd95d", null ],
    [ "ui8Flags", "struct__ni__nvme__id__power__state.html#a0f38c5901b0f51848560918beaa7e323", null ],
    [ "ui8IdleScale", "struct__ni__nvme__id__power__state.html#a60c5e1950ba085cccc3ac3d44c0155c5", null ],
    [ "ui8ReadLat", "struct__ni__nvme__id__power__state.html#a7ebaeac34f9c6e277f234e56abac521b", null ],
    [ "ui8ReadTput", "struct__ni__nvme__id__power__state.html#a15ddb9f78eb205f9c7a21bc3b78d3068", null ],
    [ "ui8Rsvd19", "struct__ni__nvme__id__power__state.html#a15f1844884658c4c7deaa717d572c8ad", null ],
    [ "ui8Rsvd2", "struct__ni__nvme__id__power__state.html#a030b31d1ed9d2c2e2426adab98dbca3f", null ],
    [ "ui8WriteLat", "struct__ni__nvme__id__power__state.html#a66a062338c52453bc83d62aea5a0ba61", null ],
    [ "ui8WriteTput", "struct__ni__nvme__id__power__state.html#a00f0f3da4cd85591d84f7027c5d22858", null ]
];