var ni__lat__meas_8c =
[
    [ "ni_lat_meas_q_add_entry", "ni__lat__meas_8c.html#aaf75bcdb4c0528596bbc8b155c9fc27f", null ],
    [ "ni_lat_meas_q_check_latency", "ni__lat__meas_8c.html#ae9aa537d3d8f9fecc3e2a58570f9b656", null ],
    [ "ni_lat_meas_q_create", "ni__lat__meas_8c.html#a4ba375a69db00fc47653c05908700b5b", null ],
    [ "ni_lat_meas_q_dequeue", "ni__lat__meas_8c.html#ac195e35f0ca9519566675e4d7ab52fcf", null ],
    [ "ni_lat_meas_q_destroy", "ni__lat__meas_8c.html#a6f5b83173fbfb957cc0c3fa06da3ebe5", null ],
    [ "ni_lat_meas_q_enqueue", "ni__lat__meas_8c.html#a536ac485bad7159a0a6fe919791f26a9", null ],
    [ "ni_lat_meas_q_front", "ni__lat__meas_8c.html#a501535856fe8e983fd729a8ba9c921eb", null ],
    [ "ni_lat_meas_q_rear", "ni__lat__meas_8c.html#a3a6a18118ad6be3163c59817bd949bb4", null ]
];