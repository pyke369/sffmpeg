var struct_scaling_list =
[
    [ "sl", "struct_scaling_list.html#a0608a1b595eeb3dca1baf3648b624a4b", null ],
    [ "sl_dc", "struct_scaling_list.html#a7d8e7ed90864f9bd138f6bf7fc08f897", null ]
];