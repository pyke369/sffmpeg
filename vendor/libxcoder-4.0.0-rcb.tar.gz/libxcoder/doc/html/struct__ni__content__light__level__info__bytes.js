var struct__ni__content__light__level__info__bytes =
[
    [ "max_content_light_level", "struct__ni__content__light__level__info__bytes.html#a3c32b01c880292f29d8884ec58ffdddc", null ],
    [ "max_pic_average_light_level", "struct__ni__content__light__level__info__bytes.html#ae1354e37cf14da084b0ee1fcc3b6e55f", null ]
];