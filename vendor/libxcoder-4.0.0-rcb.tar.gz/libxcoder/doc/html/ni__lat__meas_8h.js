var ni__lat__meas_8h =
[
    [ "_ni_lat_meas_q_entry_t", "struct__ni__lat__meas__q__entry__t.html", "struct__ni__lat__meas__q__entry__t" ],
    [ "_ni_lat_meas_q_t", "struct__ni__lat__meas__q__t.html", "struct__ni__lat__meas__q__t" ],
    [ "ni_lat_meas_q_entry_t", "ni__lat__meas_8h.html#a8b35d50942553503a923c48a02cf85fd", null ],
    [ "ni_lat_meas_q_t", "ni__lat__meas_8h.html#a841f98a268f28e1a73e1067746758cbc", null ],
    [ "ni_lat_meas_q_add_entry", "ni__lat__meas_8h.html#aaf75bcdb4c0528596bbc8b155c9fc27f", null ],
    [ "ni_lat_meas_q_check_latency", "ni__lat__meas_8h.html#ae9aa537d3d8f9fecc3e2a58570f9b656", null ],
    [ "ni_lat_meas_q_create", "ni__lat__meas_8h.html#a4ba375a69db00fc47653c05908700b5b", null ],
    [ "ni_lat_meas_q_destroy", "ni__lat__meas_8h.html#a6f5b83173fbfb957cc0c3fa06da3ebe5", null ]
];