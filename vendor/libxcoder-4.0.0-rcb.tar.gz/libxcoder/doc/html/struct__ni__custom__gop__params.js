var struct__ni__custom__gop__params =
[
    [ "custom_gop_size", "struct__ni__custom__gop__params.html#a6c01254e2506defe6a9627dee4d275c2", null ],
    [ "pic_param", "struct__ni__custom__gop__params.html#a97c57dd3d3aade411b670c4fee49612d", null ]
];