var struct__ni__device__video__capability =
[
    [ "additional_info", "struct__ni__device__video__capability.html#acdf47a15da590d16f3040f342968bb0a", null ],
    [ "level", "struct__ni__device__video__capability.html#a8d5d20b9d820377baf02a3e07793e344", null ],
    [ "max_res_height", "struct__ni__device__video__capability.html#a8397681bb260b624a183fe899acfc37b", null ],
    [ "max_res_width", "struct__ni__device__video__capability.html#a994424a3475e5591b52d063563ba1ac8", null ],
    [ "min_res_height", "struct__ni__device__video__capability.html#afa619221f0365cede6753285b3c70a6e", null ],
    [ "min_res_width", "struct__ni__device__video__capability.html#ae2b3b24ce9e2366832457317443f65b1", null ],
    [ "profiles_supported", "struct__ni__device__video__capability.html#aafd52b3c17a58c862757c741d0ae38eb", null ],
    [ "supports_codec", "struct__ni__device__video__capability.html#a1a5642318eb9ad92abe2b078efd49844", null ]
];