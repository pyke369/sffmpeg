var struct__ni_frame_surface1 =
[
    [ "bit_depth", "struct__ni_frame_surface1.html#aed2d21a7a532714c83784bc1bb0b6cb0", null ],
    [ "device_handle", "struct__ni_frame_surface1.html#a09ae96035bb9a8bf9bba18a9960abe8c", null ],
    [ "dma_buf_fd", "struct__ni_frame_surface1.html#a32f8371676bafd203370b455fdff9ecd", null ],
    [ "encoding_type", "struct__ni_frame_surface1.html#aae1d4cd59c710241ef2596bba4d3ddec", null ],
    [ "output_idx", "struct__ni_frame_surface1.html#a80f4c691ad5d6207c09f317e3e34591d", null ],
    [ "src_cpu", "struct__ni_frame_surface1.html#af80b5d8da1bc6a53232228bc14ac166d", null ],
    [ "ui16FrameIdx", "struct__ni_frame_surface1.html#a8f8347843a4949d3efcb40ccdfb53f01", null ],
    [ "ui16height", "struct__ni_frame_surface1.html#a38a23d6a42983ca801254694bae982e5", null ],
    [ "ui16session_ID", "struct__ni_frame_surface1.html#ad630e122949132661442c78c836a29b4", null ],
    [ "ui16width", "struct__ni_frame_surface1.html#a1b11126104709a505c076394ce99b4a6", null ],
    [ "ui32nodeAddress", "struct__ni_frame_surface1.html#a4970361af940680136f272f91bf4982d", null ]
];