var structni__decoder__output__config__t =
[
    [ "sCroppingRectable", "structni__decoder__output__config__t.html#abd4c006119023c63aa3cc0addda36c2e", null ],
    [ "sOutputPictureSize", "structni__decoder__output__config__t.html#a50042d52958f000d051e03fb6fbe278b", null ],
    [ "ui16Rsvd2", "structni__decoder__output__config__t.html#a9cfd389f14892210d46fe2b281676b49", null ],
    [ "ui8CropMode", "structni__decoder__output__config__t.html#a7dd51d159edef12ba21b3f269562de2c", null ],
    [ "ui8Enabled", "structni__decoder__output__config__t.html#aa033bebc74a4fc12974fb74936cbcb9e", null ],
    [ "ui8Force8Bit", "structni__decoder__output__config__t.html#a034af57df7866f1b38c3d6077aa01a6b", null ],
    [ "ui8Rsvd1", "structni__decoder__output__config__t.html#a2aea31a9c7c8c225624db0dd1755cc5e", null ],
    [ "ui8ScaleEnabled", "structni__decoder__output__config__t.html#a587e5f627946a1224255db3c2dc9b88e", null ],
    [ "ui8SemiPlanarEnabled", "structni__decoder__output__config__t.html#aa19bcb89f350eb26ddf91a031fbbfe8a", null ]
];