var ni__log_8h =
[
    [ "ni_log_level_t", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbe", [
      [ "NI_LOG_INVALID", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbeaf249b8380fba8521d6ee4bc831bc021e", null ],
      [ "NI_LOG_NONE", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbea44633360ee0bc7105db4aeb9d151d290", null ],
      [ "NI_LOG_FATAL", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbeae738af8647ef2c7a73e3a9758c9988d0", null ],
      [ "NI_LOG_ERROR", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbeae7883838103735635f8bf9892e6d2329", null ],
      [ "NI_LOG_INFO", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbeaef7cbbc46f6f752577d7b0d111ed7bb2", null ],
      [ "NI_LOG_DEBUG", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbeacd3ba0b63c1155a2f2ca54c0037832df", null ],
      [ "NI_LOG_TRACE", "ni__log_8h.html#a70ef5e25347290f762b2a7eb21970dbead3ee4446c4aa59863cdcb7760bd2cc20", null ]
    ] ],
    [ "arg_to_ni_log_level", "ni__log_8h.html#a4899f36ed48fefc564324397ef5b891b", null ],
    [ "ff_to_ni_log_level", "ni__log_8h.html#ad80d7683d4f31dfe72f2e65b60aebb5b", null ],
    [ "ni_log", "ni__log_8h.html#afb90f04b540b530bb57c5fa794ae271d", null ],
    [ "ni_log_default_callback", "ni__log_8h.html#ae9f192760635b2fe2db6e589645f5062", null ],
    [ "ni_log_get_level", "ni__log_8h.html#af9070f83614c9803548037f318f6a2ea", null ],
    [ "ni_log_set_callback", "ni__log_8h.html#aa8b6677a7ab6ab385c2c3c500c94c872", null ],
    [ "ni_log_set_level", "ni__log_8h.html#a74b5cb59d34c25dc3382daa28ce7eec8", null ]
];