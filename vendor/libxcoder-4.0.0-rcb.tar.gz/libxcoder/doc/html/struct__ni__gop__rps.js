var struct__ni__gop__rps =
[
    [ "ref_pic", "struct__ni__gop__rps.html#a94161b387cde48cb68650a1ef2d1b456", null ],
    [ "ref_pic_used", "struct__ni__gop__rps.html#a264f45e2dd4233682da08320ea00cfa0", null ]
];