var struct__ni__instance__mgr__general__status =
[
    [ "active_hwupload_sub_inst_cnt", "struct__ni__instance__mgr__general__status.html#a4ed7df0e828fb3f793bb25922effc39e", null ],
    [ "active_sub_instances_cnt", "struct__ni__instance__mgr__general__status.html#a0bf64d9cad8fedc9cd98c89caafb85b9", null ],
    [ "cmd_queue_count", "struct__ni__instance__mgr__general__status.html#a5733ad5ab1fdf9eff125ecd4f1e5f146", null ],
    [ "error_count", "struct__ni__instance__mgr__general__status.html#a2029e9c9788de523ece2dabbc7ffe2c7", null ],
    [ "fatal_error", "struct__ni__instance__mgr__general__status.html#aec5d00cffd5f2616c9ea9a15e76f293d", null ],
    [ "fw_model_load", "struct__ni__instance__mgr__general__status.html#a6e8ba5bf553e52fd32116f7402a8ae66", null ],
    [ "fw_p2p_mem_usage", "struct__ni__instance__mgr__general__status.html#a5570faaf8ae6582105e73ae3ae850330", null ],
    [ "fw_share_mem_usage", "struct__ni__instance__mgr__general__status.html#af49a8699f6cbfbddd0618bd3b364e6fb", null ],
    [ "fw_video_mem_usage", "struct__ni__instance__mgr__general__status.html#adbc095088be9a83c11c073368096afba", null ],
    [ "process_load_percent", "struct__ni__instance__mgr__general__status.html#a1da1b7243a38cf621b15dae2123d4763", null ],
    [ "ui8reserved", "struct__ni__instance__mgr__general__status.html#ae3e166b04be7fa4427f47110b3546679", null ]
];