var struct__ni__session__stats =
[
    [ "reserved", "struct__ni__session__stats.html#aa9ca83c28f3e771b5d303fed6d25570c", null ],
    [ "ui16ErrorCount", "struct__ni__session__stats.html#ab95ea4e99794f110a825b9ab08d79e7f", null ],
    [ "ui16SessionId", "struct__ni__session__stats.html#a1644a6dd946171cf08f4af924a382ada", null ],
    [ "ui32LastErrorStatus", "struct__ni__session__stats.html#aa0e33071612245ac19f9f5765ccb5311", null ],
    [ "ui32LastErrorTransactionId", "struct__ni__session__stats.html#aed54326ec568cb20c844f6c47bdd1362", null ],
    [ "ui32LastTransactionCompletionStatus", "struct__ni__session__stats.html#a7879379285f18fe4a1a4271c429d6d2b", null ],
    [ "ui32LastTransactionId", "struct__ni__session__stats.html#a2e426dc87315e325d3e50a3e4f4f2a58", null ],
    [ "ui64Session_timestamp", "struct__ni__session__stats.html#adb6cf17405f3acac7c525e62951dee81", null ]
];