var struct__ni__bitstream__reader__t =
[
    [ "bit_offset", "struct__ni__bitstream__reader__t.html#a17205733d8626bb2149a4f08f6100d0e", null ],
    [ "buf", "struct__ni__bitstream__reader__t.html#a3ee1418aab00e186fcbf06dc04217bc4", null ],
    [ "byte_offset", "struct__ni__bitstream__reader__t.html#af027b795b694cf0fd8448f764aae2c77", null ],
    [ "size_in_bits", "struct__ni__bitstream__reader__t.html#ab4d9846954ffa21e89d99797efef8b26", null ]
];