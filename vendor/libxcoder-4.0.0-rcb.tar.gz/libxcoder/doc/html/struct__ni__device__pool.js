var struct__ni__device__pool =
[
    [ "lock", "struct__ni__device__pool.html#ad70c9254e2a51831bfd8b769d977a6a9", null ],
    [ "p_device_queue", "struct__ni__device__pool.html#a13f13b4129de1f549238ddba449c6398", null ]
];