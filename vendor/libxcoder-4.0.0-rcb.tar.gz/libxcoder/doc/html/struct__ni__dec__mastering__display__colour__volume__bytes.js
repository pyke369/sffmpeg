var struct__ni__dec__mastering__display__colour__volume__bytes =
[
    [ "display_primaries", "struct__ni__dec__mastering__display__colour__volume__bytes.html#a982e5bfc65fbeac3f64710d8ed08dd8d", null ],
    [ "max_display_mastering_luminance", "struct__ni__dec__mastering__display__colour__volume__bytes.html#a33a43a4d4fa9420654e664d32c5a6b1a", null ],
    [ "min_display_mastering_luminance", "struct__ni__dec__mastering__display__colour__volume__bytes.html#a048665ea9a118db6faaca30ceabc3c26", null ],
    [ "white_point_x", "struct__ni__dec__mastering__display__colour__volume__bytes.html#a6efbaf2334092bec85153aa77fb6fa3f", null ],
    [ "white_point_y", "struct__ni__dec__mastering__display__colour__volume__bytes.html#ad27d832e187368426e0167788193f547", null ]
];