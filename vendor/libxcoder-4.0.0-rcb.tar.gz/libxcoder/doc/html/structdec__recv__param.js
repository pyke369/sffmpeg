var structdec__recv__param =
[
    [ "mode", "structdec__recv__param.html#a1ea5d0cb93f22f7d0fdf804bd68c3326", null ],
    [ "output_video_height", "structdec__recv__param.html#a986802bad20afdfb36e308f1f34841f9", null ],
    [ "output_video_width", "structdec__recv__param.html#ad15d2463ad113708e6bf825960122baf", null ],
    [ "p_dec_ctx", "structdec__recv__param.html#aa876a317f0d32be2ff820fffcb6994a1", null ],
    [ "p_file", "structdec__recv__param.html#ac721ca0e57348a01816239cba7c589d1", null ],
    [ "p_out_frame", "structdec__recv__param.html#aa64eedab1df84905e75b3815bed93c8b", null ],
    [ "p_total_bytes_received", "structdec__recv__param.html#a2443e5b6f82cc9151a9021c909114f33", null ],
    [ "p_xcodeState", "structdec__recv__param.html#a02de17edc0141e70c1b9fe08b7952c1c", null ],
    [ "test_frame_list", "structdec__recv__param.html#ab9fcb0ebe4cd2a0701aa94e4d1542a1f", null ]
];