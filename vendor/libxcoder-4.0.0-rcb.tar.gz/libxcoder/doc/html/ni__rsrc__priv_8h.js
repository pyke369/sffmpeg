var ni__rsrc__priv_8h =
[
    [ "CODERS_LCK_NAME", "ni__rsrc__priv_8h.html#a15059e74b720ecc9677a0561224cfc66", null ],
    [ "CODERS_SHM_NAME", "ni__rsrc__priv_8h.html#a7262999e6bd54339d11f90e008338eef", null ],
    [ "LOCK_DIR", "ni__rsrc__priv_8h.html#aa7f4787da1c1b2255c5617df33b8225c", null ],
    [ "LOCK_WAIT", "ni__rsrc__priv_8h.html#a92ad796dd0adc2da08468a220376fe76", null ],
    [ "MAX_LOCK_RETRY", "ni__rsrc__priv_8h.html#aa0ae97f786044a5de506c45c52608a74", null ],
    [ "ni_is_fw_compatible", "ni__rsrc__priv_8h.html#ab4cf0bf1e24cbdfc21b41baf7168a636", null ],
    [ "ni_rsrc_enumerate_devices", "ni__rsrc__priv_8h.html#ab5c55fac7388b7b7899a0bd036db51b5", null ],
    [ "ni_rsrc_fill_device_info", "ni__rsrc__priv_8h.html#a46c8ad8263b7fc520ff237d00d9c51d3", null ],
    [ "ni_rsrc_get_lock_name", "ni__rsrc__priv_8h.html#a5e95a7589304087ada735d0eb6d6a980", null ],
    [ "ni_rsrc_get_one_device_info", "ni__rsrc__priv_8h.html#a7863fef6ad9656ddca545b83a1b48a2f", null ],
    [ "ni_rsrc_get_shm_name", "ni__rsrc__priv_8h.html#a4561ae0d980be86add9c589340215bf0", null ],
    [ "ni_rsrc_strcmp", "ni__rsrc__priv_8h.html#ac200a1532aff2308fac6aedc71935d15", null ],
    [ "ni_rsrc_update_record", "ni__rsrc__priv_8h.html#a5ef9ae00327af0841c370f7ea2f379d1", null ],
    [ "g_xcoder_stop_process", "ni__rsrc__priv_8h.html#a3bedac5dddf34e3e6b4faa4691d34f1d", null ]
];