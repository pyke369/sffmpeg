var struct__ni__region__of__interest =
[
    [ "bottom", "struct__ni__region__of__interest.html#a323a7064fba6e15e3e542e34fb19764e", null ],
    [ "left", "struct__ni__region__of__interest.html#ad8f5e19e19f12974c9713e920ec54331", null ],
    [ "qoffset", "struct__ni__region__of__interest.html#a0e008666f81cbb88cb9f410e955c6379", null ],
    [ "right", "struct__ni__region__of__interest.html#a2f54f8b71f0d765e2b7dbd9a8b9774ff", null ],
    [ "self_size", "struct__ni__region__of__interest.html#a3bbc5f9f19474f3971334fecbdb062f8", null ],
    [ "top", "struct__ni__region__of__interest.html#af93f4f37fc2ad9c37af4a715423b110c", null ]
];