var struct__ni__dynamic__hdr__plus =
[
    [ "application_version", "struct__ni__dynamic__hdr__plus.html#a241302ab4beca0da6ba1d2c4f9632dbe", null ],
    [ "itu_t_t35_country_code", "struct__ni__dynamic__hdr__plus.html#ab913422485f0b1a6bb99ce52f326a1c5", null ],
    [ "mastering_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#a995b806f0d70a9d7d1e5c63d99d913dd", null ],
    [ "mastering_display_actual_peak_luminance_flag", "struct__ni__dynamic__hdr__plus.html#ac770084fbfe0834f443443eccf9a9a1d", null ],
    [ "num_cols_mastering_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#a929526da578637d10979cf19323af76d", null ],
    [ "num_cols_targeted_system_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#a2ea2e811f8a78b08eb19346281e3f3d7", null ],
    [ "num_rows_mastering_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#a635a0553a641255e9b5186c46d676ed8", null ],
    [ "num_rows_targeted_system_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#a6e9dbb191cdd1979051b77d08c81e57c", null ],
    [ "num_windows", "struct__ni__dynamic__hdr__plus.html#a5bdd06a74e79d423bea899493927fc73", null ],
    [ "params", "struct__ni__dynamic__hdr__plus.html#acd2ed871522e660c1f7b23aa4bb3fb5a", null ],
    [ "targeted_system_display_actual_peak_luminance", "struct__ni__dynamic__hdr__plus.html#adf21cf2a1881252c000474c7e8803364", null ],
    [ "targeted_system_display_actual_peak_luminance_flag", "struct__ni__dynamic__hdr__plus.html#a0c7d9ba818c498b9a0822d3743bc5d1a", null ],
    [ "targeted_system_display_maximum_luminance", "struct__ni__dynamic__hdr__plus.html#a964c38c1ae002ec164e9725aaaa99391", null ]
];