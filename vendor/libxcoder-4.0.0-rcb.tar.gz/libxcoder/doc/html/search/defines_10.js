var searchData=
[
  ['rc_5ferror_6779',['RC_ERROR',['../ni__device__api_8h.html#a993a04d3d34ab3326d1786c66e3aaa1a',1,'ni_device_api.h']]],
  ['rc_5fsuccess_6780',['RC_SUCCESS',['../ni__device__api_8h.html#a7a3ecae5ee6b127e31b975aff78df8a7',1,'ni_device_api.h']]],
  ['rd_5foffset_5fin_5f4k_6781',['RD_OFFSET_IN_4K',['../ni__nvme_8h.html#aefffb52a2a12501cd5858bbe05c9991b',1,'ni_nvme.h']]],
  ['read_5finstance_5fr_6782',['READ_INSTANCE_R',['../ni__nvme_8h.html#acbbe10db29b6693fb32830d892a2369c',1,'ni_nvme.h']]],
  ['read_5finstance_5fset_5fdw10_5fsubtype_6783',['READ_INSTANCE_SET_DW10_SUBTYPE',['../ni__nvme_8h.html#aaad7db713c0bfd3beeb6531d931acafb',1,'ni_nvme.h']]],
  ['read_5finstance_5fset_5fdw11_5finstance_6784',['READ_INSTANCE_SET_DW11_INSTANCE',['../ni__nvme_8h.html#a8b9a04366a9b54df3a230dfda1a58fb2',1,'ni_nvme.h']]],
  ['read_5finstance_5fset_5fdw15_5fsize_6785',['READ_INSTANCE_SET_DW15_SIZE',['../ni__nvme_8h.html#aafc068ebb7932b792cec352c4320b800',1,'ni_nvme.h']]],
  ['recycle_5fbuffer_5fset_5fdw10_5fbufid_6786',['RECYCLE_BUFFER_SET_DW10_BUFID',['../ni__nvme_8h.html#af6b168af46c05e42f1230f0d5da44bed',1,'ni_nvme.h']]],
  ['required_5fargument_6787',['required_argument',['../ni__getopt_8h.html#a6ece8d8dfa8378778f7290fdaba5b8bc',1,'ni_getopt.h']]],
  ['rotleft_6788',['ROTLEFT',['../ni__util_8c.html#aa554f63b1bff923e477da72974a8ca9a',1,'ni_util.c']]],
  ['rotright_6789',['ROTRIGHT',['../ni__util_8c.html#a3f24e956e9863a34a6f07be0b06b093a',1,'ni_util.c']]],
  ['round_5fto_5fulong_6790',['ROUND_TO_ULONG',['../ni__nvme_8c.html#aa83dc81688cea2241174ac077b9b87e0',1,'ni_nvme.c']]]
];
