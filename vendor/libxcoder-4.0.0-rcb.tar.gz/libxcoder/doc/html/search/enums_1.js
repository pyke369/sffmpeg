var searchData=
[
  ['gop_5fpreset_5ft_5623',['gop_preset_t',['../ni__av__codec_8c.html#aa78bc3d5bfc68f9cb9a91c02916598dc',1,'ni_av_codec.c']]]
];
