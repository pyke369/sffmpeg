var searchData=
[
  ['qlevel_4937',['qlevel',['../struct__ni__encoder__cfg__params.html#aae1ea835cf8bc65ff541df4508b4079c',1,'_ni_encoder_cfg_params']]],
  ['qoffset_4938',['qoffset',['../struct__ni__region__of__interest.html#a0e008666f81cbb88cb9f410e955c6379',1,'_ni_region_of_interest']]],
  ['qp_5fbd_5foffset_4939',['qp_bd_offset',['../struct__ni__h265__sps__t.html#a697b6acc8ad652a0debe40a562a261cd',1,'_ni_h265_sps_t']]],
  ['qp_5ffactor_4940',['qp_factor',['../struct__ni__gop__params.html#a18159f0c8bfc0ef1d4f84c65f4312f7d',1,'_ni_gop_params']]],
  ['qp_5finfo_4941',['qp_info',['../union__ni__enc__quad__roi__custom__map.html#adc3a4236676628de647fe8ec7ce2d784',1,'_ni_enc_quad_roi_custom_map']]],
  ['qp_5foffset_4942',['qp_offset',['../struct__ni__gop__params.html#aaf766de4c5bfa22e8bfdedd60e5e9ce7',1,'_ni_gop_params']]],
  ['quant_5fdata_4943',['quant_data',['../struct__ni__network__layer__params__t.html#aa36991e4054b9d04e7e7c2015fc75c79',1,'_ni_network_layer_params_t']]],
  ['quant_5fformat_4944',['quant_format',['../struct__ni__network__layer__params__t.html#a8ccab6857970d9fba1ab46bc6dd48bee',1,'_ni_network_layer_params_t']]]
];
