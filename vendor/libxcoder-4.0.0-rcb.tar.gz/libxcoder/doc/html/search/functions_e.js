var searchData=
[
  ['updatecoderload_3934',['updateCoderLoad',['../test__rsrc__api_8c.html#aae4635497e39e81081898dd004acd4cf',1,'test_rsrc_api.c']]],
  ['upload_5fsend_5fdata_5fget_5fdesc_3935',['upload_send_data_get_desc',['../ni__device__test_8c.html#a49ad09685e8054a8d49e799b9b635edf',1,'ni_device_test.c']]],
  ['uploader_5fopen_5fsession_3936',['uploader_open_session',['../ni__device__test_8c.html#a06a12979c92a67437efec961e9aafe79',1,'uploader_open_session(ni_session_context_t *p_upl_ctx, int iXcoderGUID, int src_bit_depth, int width, int height, int is_planar, int pool_size):&#160;ni_device_test.c'],['../ni__p2p__test_8c.html#adc890f66887427f50d5696e707a73251',1,'uploader_open_session(ni_session_context_t *p_upl_ctx, int *iXcoderGUID, int width, int height):&#160;ni_p2p_test.c']]],
  ['uploader_5fthread_3937',['uploader_thread',['../ni__device__test_8c.html#ab7ca841e6b23d9cdb3693eab197c0a69',1,'ni_device_test.c']]]
];
