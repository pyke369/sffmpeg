var searchData=
[
  ['crop_5fauto_5641',['CROP_AUTO',['../ni__device__api__priv_8h.html#ac42c7ba0aaea0a4fba0a8a4184c5e449ad78bb304e20552dda1374f008b56aae6',1,'ni_device_api_priv.h']]],
  ['crop_5fdisabled_5642',['CROP_DISABLED',['../ni__device__api__priv_8h.html#ac42c7ba0aaea0a4fba0a8a4184c5e449a317f36f564e5675b137f92ab26d3028d',1,'ni_device_api_priv.h']]],
  ['crop_5fmanual_5643',['CROP_MANUAL',['../ni__device__api__priv_8h.html#ac42c7ba0aaea0a4fba0a8a4184c5e449a5ba518316f860819c0da87638c1b613e',1,'ni_device_api_priv.h']]]
];
