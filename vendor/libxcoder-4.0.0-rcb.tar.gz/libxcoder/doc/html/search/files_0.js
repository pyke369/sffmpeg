var searchData=
[
  ['init_5frsrc_2ec_3534',['init_rsrc.c',['../init__rsrc_8c.html',1,'']]]
];
