var searchData=
[
  ['xcoder_5fapp_5fdecode_6806',['XCODER_APP_DECODE',['../ni__device__test_8h.html#ac82ff02954350ef02dfea1ad8b8fe284',1,'ni_device_test.h']]],
  ['xcoder_5fapp_5fencode_6807',['XCODER_APP_ENCODE',['../ni__device__test_8h.html#a1cad8e18d49fd29509de9127700d1b59',1,'ni_device_test.h']]],
  ['xcoder_5fapp_5ffilter_6808',['XCODER_APP_FILTER',['../ni__device__test_8h.html#af34be35312cafae05c28efbd293e1947',1,'ni_device_test.h']]],
  ['xcoder_5fapp_5fhwup_5fencode_6809',['XCODER_APP_HWUP_ENCODE',['../ni__device__test_8h.html#aa45eeedf118da4edf9c203f05ee8b18d',1,'ni_device_test.h']]],
  ['xcoder_5fapp_5ftranscode_6810',['XCODER_APP_TRANSCODE',['../ni__device__test_8h.html#a32a7450a8f17e7886cfccc12d1494a97',1,'ni_device_test.h']]],
  ['xcoder_5fframe_5foffset_5fdiff_5fthres_6811',['XCODER_FRAME_OFFSET_DIFF_THRES',['../ni__util_8h.html#af39c7ca63c9048d40cc24c9e17bb59d0',1,'ni_util.h']]],
  ['xcoder_5fmax_5fenc_5fpackets_5fper_5fread_6812',['XCODER_MAX_ENC_PACKETS_PER_READ',['../ni__util_8h.html#ac30ff6ab788674133bc00516ea369d92',1,'ni_util.h']]],
  ['xcoder_5fmax_5fenc_5fpic_5fheight_6813',['XCODER_MAX_ENC_PIC_HEIGHT',['../ni__util_8h.html#a0f81ad8d59debc4cc51a93798e9856fe',1,'ni_util.h']]],
  ['xcoder_5fmax_5fenc_5fpic_5fwidth_6814',['XCODER_MAX_ENC_PIC_WIDTH',['../ni__util_8h.html#ac5cb89c48a7850e3c7dd03640b573c04',1,'ni_util.h']]],
  ['xcoder_5fmax_5fnum_5fqueue_5fentries_6815',['XCODER_MAX_NUM_QUEUE_ENTRIES',['../ni__util_8h.html#a84007ae6fce7b6ac47a8caefd9d5c1ad',1,'ni_util.h']]],
  ['xcoder_5fmax_5fnum_5ftemporal_5flayer_6816',['XCODER_MAX_NUM_TEMPORAL_LAYER',['../ni__util_8h.html#a6b50e0f756c359df9765adc5d935a36e',1,'ni_util.h']]],
  ['xcoder_5fmax_5fnum_5fts_5ftable_6817',['XCODER_MAX_NUM_TS_TABLE',['../ni__util_8h.html#a912a4fc854e77cdf249f9afa97f30379',1,'ni_util.h']]],
  ['xcoder_5fmin_5fenc_5fpic_5fheight_6818',['XCODER_MIN_ENC_PIC_HEIGHT',['../ni__util_8h.html#aa4846f7a04a2ee2a300e2e02e63dc4ae',1,'ni_util.h']]],
  ['xcoder_5fmin_5fenc_5fpic_5fwidth_6819',['XCODER_MIN_ENC_PIC_WIDTH',['../ni__util_8h.html#a2fcedcf0cb0121f03286dc49539f9aa1',1,'ni_util.h']]]
];
