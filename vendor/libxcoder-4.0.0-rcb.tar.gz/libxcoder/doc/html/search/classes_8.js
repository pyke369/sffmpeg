var searchData=
[
  ['tensor_5frsrc_3531',['tensor_rsrc',['../structtensor__rsrc.html',1,'']]]
];
