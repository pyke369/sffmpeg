var searchData=
[
  ['init_5fscaler_5fparams_3613',['init_scaler_params',['../ni__device__test_8c.html#a3f1756c460f3fd16d139a1740ba05b91',1,'ni_device_test.c']]],
  ['is_5fsupported_5fxcoder_3614',['is_supported_xcoder',['../ni__defs_8h.html#aea04b4e3b7f13441b7291dcae8f9ad9d',1,'ni_defs.h']]]
];
