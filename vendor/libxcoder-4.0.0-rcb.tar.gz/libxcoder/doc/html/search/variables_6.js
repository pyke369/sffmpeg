var searchData=
[
  ['g_5fcurr_5fcache_5fpos_4289',['g_curr_cache_pos',['../ni__p2p__test_8c.html#a29524c9b2c341408d502a02a96f4ab1e',1,'ni_p2p_test.c']]],
  ['g_5fdevice_5freference_5ftable_4290',['g_device_reference_table',['../ni__rsrc__api_8cpp.html#a6bf76e46d900405036aa170767cd69c2',1,'ni_rsrc_api.cpp']]],
  ['g_5frepeat_4291',['g_repeat',['../ni__device__test_8c.html#a5ce4992446a65e31da5b454535d97887',1,'g_repeat():&#160;ni_device_test.c'],['../ni__p2p__test_8c.html#ad82bf24b218032fa74d461931f44d73d',1,'g_repeat():&#160;ni_p2p_test.c']]],
  ['g_5fxcoder_5flog_5fnames_4292',['g_xcoder_log_names',['../ni__device__api_8c.html#a14ee08f5ebace8a18878705b4e02fc1a',1,'g_xcoder_log_names():&#160;ni_device_api.c'],['../ni__device__api_8h.html#a3bba5d8523940c5ec039aa0bec7c0aad',1,'g_xcoder_log_names():&#160;ni_device_api.c']]],
  ['g_5fxcoder_5fpreset_5fnames_4293',['g_xcoder_preset_names',['../ni__device__api_8c.html#a95dbbd03cfab10bee74fcc5d1ba3b258',1,'g_xcoder_preset_names():&#160;ni_device_api.c'],['../ni__device__api_8h.html#a0ff650e620682516a4d2057bdb1dbc39',1,'g_xcoder_preset_names():&#160;ni_device_api.c']]],
  ['g_5fxcoder_5fstop_5fprocess_4294',['g_xcoder_stop_process',['../ni__rsrc__priv_8cpp.html#a0bfb117bd9408257eeb4d67ea0c3897f',1,'g_xcoder_stop_process():&#160;ni_rsrc_priv.cpp'],['../ni__rsrc__priv_8h.html#a3bedac5dddf34e3e6b4faa4691d34f1d',1,'g_xcoder_stop_process():&#160;ni_rsrc_priv.cpp']]],
  ['g_5fyuv_5fframe_4295',['g_yuv_frame',['../ni__p2p__test_8c.html#aa63c8eab09d1a6c89e3d1eab0339d889',1,'ni_p2p_test.c']]],
  ['gaps_5fin_5fframe_5fnum_5fallowed_5fflag_4296',['gaps_in_frame_num_allowed_flag',['../struct__ni__h264__sps__t.html#a6c5c86a418e646337e1601688e3d0ab3',1,'_ni_h264_sps_t']]],
  ['gdrduration_4297',['gdrDuration',['../struct__ni__encoder__cfg__params.html#aff847c0c7c6e1d78a809490d63d41a73',1,'_ni_encoder_cfg_params']]],
  ['general_5fptl_4298',['general_ptl',['../struct_p_t_l.html#ad68e55dd42e1b84928b0b89fd92110ea',1,'PTL']]],
  ['generate_5fenc_5fhdrs_4299',['generate_enc_hdrs',['../struct__ni__xcoder__params.html#abe880770b5f3a42f12671d8f26f42ff8',1,'_ni_xcoder_params']]],
  ['gop_5fpreset_5findex_4300',['gop_preset_index',['../struct__ni__encoder__cfg__params.html#ad0f3c78d3822f30b1ab84612ef0e7bcd',1,'_ni_encoder_cfg_params::gop_preset_index()'],['../struct__ni__t408__config__t.html#ab0b73cbef66b6ba4166889a36bb20d4a',1,'_ni_t408_config_t::gop_preset_index()']]],
  ['goplowdelay_4301',['gopLowdelay',['../struct__ni__encoder__cfg__params.html#afe753f0736c570210eb87ac190080f50',1,'_ni_encoder_cfg_params']]],
  ['gopsize_4302',['gopSize',['../struct__ni__encoder__cfg__params.html#ad0db87e2ca0c90c9609a9a82f52174a5',1,'_ni_encoder_cfg_params']]]
];
