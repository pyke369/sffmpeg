var searchData=
[
  ['read_5ffrom_5fdmabuf_3922',['read_from_dmabuf',['../ni__device__test_8c.html#a70c3fe894e1179cd2e2303aa85109c47',1,'ni_device_test.c']]],
  ['read_5fnext_5fchunk_3923',['read_next_chunk',['../ni__device__test_8c.html#a8b457fbff74a7212ca5d39cf646f6cea',1,'ni_device_test.c']]],
  ['read_5fnext_5fchunk_5ffrom_5ffile_3924',['read_next_chunk_from_file',['../ni__device__test_8c.html#a1e81b31d68066222be2267b91746e434',1,'read_next_chunk_from_file(int pfs, uint8_t *p_dst, uint32_t to_read):&#160;ni_device_test.c'],['../ni__p2p__test_8c.html#a9f5588147e55edc65be973e1e1fb6313',1,'read_next_chunk_from_file(int fd, uint8_t *p_dst, uint32_t to_read):&#160;ni_p2p_test.c']]],
  ['recycle_5fframes_3925',['recycle_frames',['../ni__p2p__test_8c.html#a88fb9f9f7c65807dd42fc00169175c7b',1,'ni_p2p_test.c']]],
  ['releaseencrsrc_3926',['releaseEncRsrc',['../test__rsrc__api_8c.html#ab5bd34cc7bc9d2106e960888fc2d3e8f',1,'test_rsrc_api.c']]],
  ['reset_5fdata_5fbuf_5fpos_3927',['reset_data_buf_pos',['../ni__device__test_8c.html#a655190fa445a6df33dfe72f31eebf030',1,'ni_device_test.c']]],
  ['rewind_5fdata_5fbuf_5fpos_5fby_3928',['rewind_data_buf_pos_by',['../ni__device__test_8c.html#afadec3211a12b35449b99132b2c2e0e8',1,'ni_device_test.c']]]
];
