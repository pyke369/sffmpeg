var searchData=
[
  ['keep_5falive_5fthread_4472',['keep_alive_thread',['../struct__ni__session__context.html#a9213713126a6cad012c0ad52fdcb5492',1,'_ni_session_context']]],
  ['keep_5falive_5fthread_5fargs_4473',['keep_alive_thread_args',['../struct__ni__session__context.html#a1eec519b08e7502520b1aa87640af37f',1,'_ni_session_context']]],
  ['keep_5falive_5ftimeout_4474',['keep_alive_timeout',['../struct__ni__thread__arg__struct__t.html#a33e5d0537c6cd318f10a943dd1a39222',1,'_ni_thread_arg_struct_t::keep_alive_timeout()'],['../struct__ni__session__context.html#a33e5d0537c6cd318f10a943dd1a39222',1,'_ni_session_context::keep_alive_timeout()'],['../struct__ni__encoder__cfg__params.html#afd09424575573de1308e3ba45c511dbe',1,'_ni_encoder_cfg_params::keep_alive_timeout()'],['../struct__ni__decoder__input__params__t.html#afd09424575573de1308e3ba45c511dbe',1,'_ni_decoder_input_params_t::keep_alive_timeout()']]],
  ['key_5fframe_5ftype_4475',['key_frame_type',['../struct__ni__session__context.html#ae2603216ff320a51d17789cc8183f6b0',1,'_ni_session_context']]],
  ['keyframe_5ffactor_4476',['keyframe_factor',['../struct__ni__session__context.html#acb2f4c740e7dfbe1f89618131ada24ff',1,'_ni_session_context']]],
  ['knee_5fpoint_5fx_4477',['knee_point_x',['../struct__ni__hdr__plus__color__transform__params.html#a6cd70268d7cf89bab1f199938df23177',1,'_ni_hdr_plus_color_transform_params']]],
  ['knee_5fpoint_5fy_4478',['knee_point_y',['../struct__ni__hdr__plus__color__transform__params.html#a55b845f7cefab44cba91c5203f1e422c',1,'_ni_hdr_plus_color_transform_params']]]
];
