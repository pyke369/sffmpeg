var searchData=
[
  ['platform_5fendianess_6748',['PLATFORM_ENDIANESS',['../ni__defs_8h.html#a9e2dea1de6fb223b4d40f312bdf16174',1,'ni_defs.h']]],
  ['pool_5fsize_6749',['POOL_SIZE',['../ni__p2p__test_8c.html#aa2ac54564b3514084afd2c5dafe9d232',1,'ni_p2p_test.c']]]
];
