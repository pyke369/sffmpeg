var searchData=
[
  ['scale_5ffilter_3929',['scale_filter',['../ni__device__test_8c.html#a4155882f721e0ff69a6df401e31334fe',1,'scale_filter(ni_session_context_t *p_ctx, ni_frame_t *p_frame_in, ni_session_data_io_t *p_data_out, int scale_width, int scale_height, int out_format):&#160;ni_device_test.c'],['../ni__device__test_8h.html#a4155882f721e0ff69a6df401e31334fe',1,'scale_filter(ni_session_context_t *p_ctx, ni_frame_t *p_frame_in, ni_session_data_io_t *p_data_out, int scale_width, int scale_height, int out_format):&#160;ni_device_test.c']]],
  ['scaler_5foutput_5fwrite_3930',['scaler_output_write',['../ni__device__test_8c.html#a392d4650ba4e29f8b2e9d42894ccc137',1,'ni_device_test.c']]],
  ['scaler_5fsession_5fopen_3931',['scaler_session_open',['../ni__device__test_8c.html#ae85b79ae2ebc1d2d5090183c24c3cc79',1,'ni_device_test.c']]],
  ['scan_5fand_5fclean_5fhwdescriptors_3932',['scan_and_clean_hwdescriptors',['../ni__device__test_8c.html#a59a3f978bc0eb385c1395273c719c027',1,'ni_device_test.c']]],
  ['set_5fdemo_5froi_5fmap_3933',['set_demo_roi_map',['../ni__device__test_8c.html#ab3a6dfc33ae33743bd55f0abfe437aac',1,'ni_device_test.c']]]
];
