var searchData=
[
  ['dec_5frecv_5fparam_3511',['dec_recv_param',['../structdec__recv__param.html',1,'']]],
  ['dec_5fsend_5fparam_3512',['dec_send_param',['../structdec__send__param.html',1,'']]]
];
