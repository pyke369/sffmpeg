var searchData=
[
  ['zeropoint_5337',['zeroPoint',['../struct__ni__network__layer__params__t.html#a26d3273f06bea34523b4a4a27f0bec54',1,'_ni_network_layer_params_t']]]
];
