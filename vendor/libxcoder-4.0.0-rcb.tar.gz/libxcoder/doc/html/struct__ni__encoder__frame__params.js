var struct__ni__encoder__frame__params =
[
    [ "data_format", "struct__ni__encoder__frame__params.html#ad77c91b6f503d8ed5a32c2b9e3e20686", null ],
    [ "force_picture_type", "struct__ni__encoder__frame__params.html#a10042cc3071a6d20bd2d729962fcf1d6", null ],
    [ "picture_type", "struct__ni__encoder__frame__params.html#aedcaed113a9e3bb164b8055a645aeb6b", null ],
    [ "timestamp", "struct__ni__encoder__frame__params.html#ab20b0c7772544cf5d318507f34231fbe", null ],
    [ "video_height", "struct__ni__encoder__frame__params.html#ae62d455c07515a709b2ccd014a29dd62", null ],
    [ "video_width", "struct__ni__encoder__frame__params.html#a7e13f7f50a6a67ac38b8a9057b677210", null ]
];