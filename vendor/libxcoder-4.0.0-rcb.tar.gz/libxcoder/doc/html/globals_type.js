var globals_type =
[
    [ "b", "globals_type.html", null ],
    [ "d", "globals_type_d.html", null ],
    [ "e", "globals_type_e.html", null ],
    [ "n", "globals_type_n.html", null ],
    [ "p", "globals_type_p.html", null ],
    [ "r", "globals_type_r.html", null ],
    [ "s", "globals_type_s.html", null ],
    [ "t", "globals_type_t.html", null ],
    [ "u", "globals_type_u.html", null ],
    [ "v", "globals_type_v.html", null ]
];