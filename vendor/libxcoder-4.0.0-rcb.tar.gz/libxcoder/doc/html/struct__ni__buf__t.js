var struct__ni__buf__t =
[
    [ "buf", "struct__ni__buf__t.html#a5bc5fa69bee375df074734a2c4858604", null ],
    [ "p_next", "struct__ni__buf__t.html#ab9cabed674118427e0365aa5a7353377", null ],
    [ "p_next_buffer", "struct__ni__buf__t.html#af7dc80ee099747b08b071ddfef87701d", null ],
    [ "p_prev", "struct__ni__buf__t.html#ae657c2464c159a68c4d73c131f2d03fc", null ],
    [ "p_previous_buffer", "struct__ni__buf__t.html#a1427f0655ccc18d368784059dd001d58", null ],
    [ "pool", "struct__ni__buf__t.html#a16f63215e7c2a9d5453ac1135679f0dd", null ]
];