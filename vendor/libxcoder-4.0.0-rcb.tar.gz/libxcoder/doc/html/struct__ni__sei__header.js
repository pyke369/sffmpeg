var struct__ni__sei__header =
[
    [ "size", "struct__ni__sei__header.html#aaba88b24a21a6c70c895c0d55f4a69a0", null ],
    [ "status", "struct__ni__sei__header.html#ade818037fd6c985038ff29656089758d", null ],
    [ "type", "struct__ni__sei__header.html#a1d127017fb298b889f4ba24752d08b8e", null ]
];