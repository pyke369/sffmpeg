var struct__ni__rsrc__video__ref__cap =
[
    [ "fps", "struct__ni__rsrc__video__ref__cap.html#a45b67662d620a977a2cfe519f7ab6273", null ],
    [ "height", "struct__ni__rsrc__video__ref__cap.html#ad12fc34ce789bce6c8a05d8a17138534", null ],
    [ "width", "struct__ni__rsrc__video__ref__cap.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];