var struct__ni__mastering__display__metadata =
[
    [ "display_primaries", "struct__ni__mastering__display__metadata.html#afb790036d309f0a402c2a44548170555", null ],
    [ "has_luminance", "struct__ni__mastering__display__metadata.html#ab8f9e1651009b47e0eda7f3775e01a08", null ],
    [ "has_primaries", "struct__ni__mastering__display__metadata.html#a11d93d6dddffd6a5bb896f044222e186", null ],
    [ "max_luminance", "struct__ni__mastering__display__metadata.html#ab5ce2a3ea1ee373cf61162f9784273fc", null ],
    [ "min_luminance", "struct__ni__mastering__display__metadata.html#a7c0aebc65d9311e71788021d0a0b0663", null ],
    [ "white_point", "struct__ni__mastering__display__metadata.html#ab0485c1fca451edca651ae333e87f7fb", null ]
];