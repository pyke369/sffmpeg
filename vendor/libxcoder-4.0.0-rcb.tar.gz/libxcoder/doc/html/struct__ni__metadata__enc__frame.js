var struct__ni__metadata__enc__frame =
[
    [ "enc_reconfig_data_size", "struct__ni__metadata__enc__frame.html#ab47afc72abf29eb6a0b33eaeb6bf7580", null ],
    [ "force_headers", "struct__ni__metadata__enc__frame.html#ac9b02ef98906d5e5e9f40dbc10fb7d5d", null ],
    [ "force_pic_qp_b", "struct__ni__metadata__enc__frame.html#ad61633c28cf27b2f44fcef41e9643c66", null ],
    [ "force_pic_qp_enable", "struct__ni__metadata__enc__frame.html#a84adc6bf64908d7f22ff2a6930d95ce6", null ],
    [ "force_pic_qp_i", "struct__ni__metadata__enc__frame.html#a1102cecf0e941023f62dd5afc8355b4f", null ],
    [ "force_pic_qp_p", "struct__ni__metadata__enc__frame.html#a82e5367b8376fb83640e1aa84ac69441", null ],
    [ "frame_force_type", "struct__ni__metadata__enc__frame.html#aaa1d91f3a9a5bc82e4f79fd572b24855", null ],
    [ "frame_force_type_enable", "struct__ni__metadata__enc__frame.html#adae7980cdbce9ea4bc33af9db871dce4", null ],
    [ "frame_roi_avg_qp", "struct__ni__metadata__enc__frame.html#ab1c85dedc25765145b48e50c9e5d6bc2", null ],
    [ "frame_roi_map_size", "struct__ni__metadata__enc__frame.html#a95158a54bf256bc60b0ab6a6c52cc910", null ],
    [ "frame_sei_data_size", "struct__ni__metadata__enc__frame.html#a0b582e936695824a6fc3d5f21f045943", null ],
    [ "metadata_common", "struct__ni__metadata__enc__frame.html#ad724728890741c81632922a3c9f307f0", null ],
    [ "use_cur_src_as_long_term_pic", "struct__ni__metadata__enc__frame.html#ad05a6157b32a4b18a0a044f1612626ac", null ],
    [ "use_long_term_ref", "struct__ni__metadata__enc__frame.html#aece195c91f62cb2a06309a05b408cf75", null ]
];