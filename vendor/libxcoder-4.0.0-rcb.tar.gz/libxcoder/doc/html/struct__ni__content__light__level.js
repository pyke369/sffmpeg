var struct__ni__content__light__level =
[
    [ "max_cll", "struct__ni__content__light__level.html#aa80bce46198c34029108c8033892f1ea", null ],
    [ "max_fall", "struct__ni__content__light__level.html#adf5c0994485374cfc9f63ef4ab4dbb3a", null ]
];