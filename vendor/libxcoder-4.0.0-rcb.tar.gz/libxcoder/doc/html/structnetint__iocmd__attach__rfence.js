var structnetint__iocmd__attach__rfence =
[
    [ "fd", "structnetint__iocmd__attach__rfence.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "fence_fd", "structnetint__iocmd__attach__rfence.html#a09cdb7c9c95556007ab9d1314bce5ca2", null ],
    [ "flags", "structnetint__iocmd__attach__rfence.html#ac92588540e8c1d014a08cd8a45462b19", null ]
];