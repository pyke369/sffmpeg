var ni__nvme_8c =
[
    [ "ROUND_TO_ULONG", "ni__nvme_8c.html#aa83dc81688cea2241174ac077b9b87e0", null ],
    [ "ni_nvme_check_error_code", "ni__nvme_8c.html#ad63f6f1229686fec8a45e8f5e1ede757", null ],
    [ "ni_nvme_send_admin_cmd", "ni__nvme_8c.html#a8d8c170b89633987a0448f4f0c756bf0", null ],
    [ "ni_nvme_send_io_cmd", "ni__nvme_8c.html#acfe2987af48855e8e717857424903570", null ],
    [ "ni_nvme_send_read_cmd", "ni__nvme_8c.html#a81b98e3ff18d304acfd995b26bab90fa", null ],
    [ "ni_nvme_send_write_cmd", "ni__nvme_8c.html#abc0fcb144d2510c91bd61b9cd9c5d61d", null ],
    [ "ni_parse_lba", "ni__nvme_8c.html#a7f054d99a228be3b35d4c061807b9ba7", null ]
];