var ni__getopt_8h =
[
    [ "option", "structoption.html", "structoption" ],
    [ "no_argument", "ni__getopt_8h.html#a3bc1d5f667b5b4ca4b4abb685dc874ce", null ],
    [ "optional_argument", "ni__getopt_8h.html#acca06c0a947656bd8b395bf1084ffb72", null ],
    [ "required_argument", "ni__getopt_8h.html#a6ece8d8dfa8378778f7290fdaba5b8bc", null ],
    [ "getopt", "ni__getopt_8h.html#a6838f5aa91969606f26429485b1354a9", null ],
    [ "getopt_long", "ni__getopt_8h.html#a5f6e71f553d4d4394e5171bb006008c7", null ],
    [ "optarg", "ni__getopt_8h.html#a92067d4e3cc2e41c57bfa019a9926e1b", null ],
    [ "opterr", "ni__getopt_8h.html#a06a0101060dc135903faf596770f907c", null ],
    [ "optind", "ni__getopt_8h.html#a8521e25ea408d42d41a8fc349d4efaed", null ],
    [ "optopt", "ni__getopt_8h.html#a7181be69e7ceb3157c203348a62b4c5f", null ]
];