var struct__ni__bitstream__writer__t =
[
    [ "cur_bit", "struct__ni__bitstream__writer__t.html#a9301c070540dcfc6711fd9cb96c0327e", null ],
    [ "data", "struct__ni__bitstream__writer__t.html#a325819a8e492ac69542e8b31705af6e9", null ],
    [ "first", "struct__ni__bitstream__writer__t.html#a1b9f129e07c6ba077fc40112eed9356b", null ],
    [ "last", "struct__ni__bitstream__writer__t.html#a69076ebd7e83f538ae1897c6d490c41d", null ],
    [ "len", "struct__ni__bitstream__writer__t.html#a96bbf959016e4411c9e6b9812a8be60a", null ]
];