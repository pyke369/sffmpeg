#include<lib.h>
#include<stdio.h>
int main(int argc, char **argv)
{
  char *t = meson_print();
  printf("%s", t);
  return 0;
}
