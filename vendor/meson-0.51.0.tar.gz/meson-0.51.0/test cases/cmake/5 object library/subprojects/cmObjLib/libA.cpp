#include "libA.hpp"

std::string getLibStr() {
  return "Hello World";
}
