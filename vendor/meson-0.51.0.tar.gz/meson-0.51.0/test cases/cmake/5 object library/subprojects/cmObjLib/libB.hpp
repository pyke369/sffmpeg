#pragma once

#include <string>

std::string getZlibVers();
