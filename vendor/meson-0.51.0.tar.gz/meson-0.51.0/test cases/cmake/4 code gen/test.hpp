#pragma once

#include <string>

std::string getStr();
