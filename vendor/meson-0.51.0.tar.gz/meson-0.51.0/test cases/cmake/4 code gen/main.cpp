#include <iostream>
#include "test.hpp"

using namespace std;

int main() {
  cout << getStr() << endl;
}
