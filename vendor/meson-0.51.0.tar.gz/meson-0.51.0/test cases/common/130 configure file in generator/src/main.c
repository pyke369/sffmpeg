#include<stdio.h>

#include"confdata.h"
#if RESULT != 42
#error Configuration RESULT is not defined correctly
#endif

#undef RESULT

#include"source.h"
#if RESULT != 23
#error Source RESULT is not defined correctly
#endif

int main(int argc, char **argv) {
    return 0;
}
