#include<stdio.h>

int main(int argc, char **argv) {
    printf("Existentialism.\n");
    return 0;
}
