#include "pch.h"

int foo() {
    return 0;
}
