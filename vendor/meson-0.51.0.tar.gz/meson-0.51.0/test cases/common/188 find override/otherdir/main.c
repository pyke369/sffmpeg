int be_seeing_you();

int main(int argc, char **argv) {
    return be_seeing_you() == 6 ? 0 : 1;
}
