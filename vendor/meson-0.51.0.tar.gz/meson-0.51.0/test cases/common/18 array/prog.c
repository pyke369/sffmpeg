extern int func();

int main(int argc, char **argv) { return func(); }
