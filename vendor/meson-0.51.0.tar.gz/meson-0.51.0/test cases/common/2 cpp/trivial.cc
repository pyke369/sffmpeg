#include<iostream>

int main(int argc, char **argv) {
  std::cout << "C++ seems to be working." << std::endl;
  return 0;
}
