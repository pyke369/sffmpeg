#pragma once

#define I_CAN_HAZ_SIMD
