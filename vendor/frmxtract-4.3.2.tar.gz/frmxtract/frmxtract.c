// mandatory includes
#include <stdio.h>
#include <string.h>
#include <libgen.h>
#include <getopt.h>
#include <sys/stat.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libswresample/swresample.h>
#include <libavutil/imgutils.h>
#include <png.h>

// defines
#define  FRMXTRACT_VERSION  "4.3.2"
#define  TRAP(c, s)         if (c) return s;
#define  QUEUE_ALLOCSIZE    (300)

// globals
int  verbose = 0, start = 0, duration = 0, count = 1, interval = 1, interval_time = 0, keyframes = 0, greyscale = 0, fingerprint = 0;
char *input = NULL, *output = "%f%-%n%.png";

// convert human-readable timecode into time
int timecode2time(char *timecode)
{
    int value = 0, fields, hour = 0, minute = 0, second = 0;
    char millisecond[16];

    if (timecode)
    {
        if ((fields = sscanf(timecode, "%02d:%02d:%02d.%s", &hour, &minute, &second, (char *)&millisecond)) >= 3)
        {
            hour    = hour < 0 ? 0 : hour;
            hour    = hour > 23 ? 23 : hour;
            minute  = minute < 0 ? 0 : minute;
            minute  = minute > 59 ? 59 : minute;
            second  = second < 0 ? 0 : second;
            second  = second > 59 ? 59 : second;
            value  += ((hour * 3600) + (minute * 60) + second) * 1000;
            if (fields == 4)
            {
                millisecond[3] = 0;
                value += atoi(millisecond);
            }
        }
        else
        {
            value = (int)(atof(timecode) * 1000);
        }
    }
    return value;
}

// convert time into human-readable timecode
char *time2timecode(int time)
{
    int         hour, minute, second;
    static char timecode[64];

    time   = time < 0 ? 0 : time;
    hour   = time / (3600 * 1000);
    time  -= hour * (3600 * 1000);
    minute = time / (60 * 1000);
    time  -= minute * (60 * 1000);
    second = time / 1000;
    time  -= second * 1000;
    sprintf(timecode, "%02d:%02d:%02d.%03d", hour, minute, second, time);
    return timecode;
}

// generate extracted frame path
void generate_path(char *path, int size, int index, int pts)
{
    char replace[BUFSIZ], *token;

    memset(path, 0, size);
    strncpy(path, output, size - 1);
    memset(replace, 0, sizeof(replace));
    strncpy(replace, basename(input), sizeof(replace) - 1);
    if((token = strrchr(replace, '.')))
    {
        *token = 0;
    }
    while ((token = strstr(path, "%f%")))
    {
        memmove(token, token + 3, strlen(token + 3) + 1);
        if (strlen(path) < size - 1 - 3 + strlen(replace))
        {
            memmove(token + strlen(replace), token, strlen(token) + 1);
            memcpy(token, replace, strlen(replace));
        }
    }
    sprintf(replace, "%06d", index);
    while ((token = strstr(path, "%n%")))
    {
        memmove(token, token + 3, strlen(token + 3) + 1);
        if (strlen(path) < size - 1 - 3 + strlen(replace))
        {
            memmove(token + strlen(replace), token, strlen(token) + 1);
            memcpy(token, replace, strlen(replace));
        }
    }
    strcpy(replace, time2timecode(pts));
    while ((token = strstr(path, "%t%")))
    {
        memmove(token, token + 3, strlen(token + 3) + 1);
        if (strlen(path) < size - 1 - 3 + strlen(replace))
        {
            memmove(token + strlen(replace), token, strlen(token) + 1);
            memcpy(token, replace, strlen(replace));
        }
    }
}

// actually perform the frames extract
int extract()
{
    AVFormatContext   *format_context = NULL;
    AVCodecContext    *codec_context = NULL;
    AVCodec           *codec = NULL;
    AVPacket          packet, *queue = NULL;
    AVFrame           *source_frame = NULL, *target_frame = NULL;
    AVRational        aspect_ratio, *base = NULL;
    struct SwsContext *scale_context;
    double            pixel_ratio, display_ratio;
    struct stat       info;
    FILE              *target;
    png_structp       png = NULL;
    png_infop         png_info = NULL;
    char              path[BUFSIZ], size[32];
    int               index, video_stream = -1, target_width, source_format = (greyscale ? AV_PIX_FMT_GRAY8 : AV_PIX_FMT_RGB24), target_format = (greyscale ? PNG_COLOR_TYPE_GRAY : PNG_COLOR_TYPE_RGB),
                      frame_index = 0, timebase = -1, timestamp, is_keyframe, extracted = 0, queue_size = 0, queue_index = 0, capture = 0, last_capture = -1, decoded, last_decoded = -1;

    TRAP(!(format_context = avformat_alloc_context()), 101);
    TRAP(avformat_open_input(&format_context, input, 0, NULL), 102);
    TRAP(avformat_find_stream_info(format_context, NULL) < 0, 103);
    for (index = 0; index < format_context->nb_streams; index++)
    {
        if (format_context->streams[index]->codec->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream = index;
            break;
        }
    }
    TRAP(video_stream < 0, 104);
    TRAP(!(codec_context = format_context->streams[video_stream]->codec), 105);
    TRAP(!(codec = avcodec_find_decoder(codec_context->codec_id)), 106);
    TRAP(avcodec_open2(codec_context, codec, NULL) < 0, 107);
    TRAP(codec_context->width == 0 || codec_context->height == 0, 108);
    pixel_ratio = display_ratio = (double)codec_context->width / (double)codec_context->height;
    av_reduce(&aspect_ratio.num, &aspect_ratio.den, codec_context->width * codec_context->sample_aspect_ratio.num, codec_context->height * codec_context->sample_aspect_ratio.den, 1024*1024);
    if (aspect_ratio.num != 0 && aspect_ratio.den != 0)
    {
        display_ratio = (double)aspect_ratio.num / (double)aspect_ratio.den;
    }
    target_width  = (int)floor(((double)codec_context->width * display_ratio) / pixel_ratio);
    TRAP(!(source_frame = av_frame_alloc()) || !(target_frame = av_frame_alloc()), 109);
    TRAP(av_image_fill_arrays(target_frame->data, target_frame->linesize, malloc(av_image_get_buffer_size(AV_PIX_FMT_RGB24, target_width, codec_context->height, 1)), source_format, target_width, codec_context->height, 1) < 0, 110);
    TRAP(!(scale_context = sws_getContext(codec_context->width, codec_context->height, codec_context->pix_fmt, target_width, codec_context->height, source_format, SWS_BICUBIC, NULL, NULL, NULL)), 111);
    base = &(format_context->streams[video_stream]->time_base);
    while (av_read_frame(format_context, &packet) >= 0)
    {
        if (packet.stream_index != video_stream)
        {
            av_packet_unref(&packet);
            continue;
        }
        if (packet.pts == AV_NOPTS_VALUE)
        {
            packet.pts = packet.dts;
        }
        timestamp = (packet.pts * base->num * 1000) / base->den;
        if (timebase < 0)
        {
            timebase = timestamp;
        }
        timestamp  -= timebase;
        is_keyframe = (packet.flags & AV_PKT_FLAG_KEY);
        if (verbose >= 2)
        {
            fprintf(stderr, "[%6d] [%s%s] [%d]\n", frame_index, time2timecode(timestamp), is_keyframe ? " K" : "  ", packet.size);
            if (verbose >= 3)
            {
                av_pkt_dump2(stderr, &packet, verbose >= 4, format_context->streams[video_stream]);
            }
        }
        if (queue_size < queue_index + 1)
        {
            TRAP(!(queue = (AVPacket *)realloc(queue, sizeof(AVPacket) * (queue_size + QUEUE_ALLOCSIZE))), 112);
            queue_size += QUEUE_ALLOCSIZE;
        }
        if (is_keyframe)
        {
            if (verbose >= 2)
            {
                fprintf(stderr, "[keyframe detected, flushing %d accumulated packet%s]\n", queue_index, queue_index > 1 ? "s" : "");
            }
            for (index = 0; index < queue_index; index ++)
            {
                av_packet_unref(&(queue[index]));
            }
            avcodec_flush_buffers(codec_context);
            last_decoded = -1;
            queue_index  = 0;
        }
        av_copy_packet(&(queue[queue_index]), &packet);
        queue_index ++;
        if (!capture && start <= timestamp && (!keyframes || (keyframes && is_keyframe)) && (last_capture < 0 || (last_capture >= 0 && ((interval_time ? timestamp : frame_index) - last_capture >= interval))))
        {
            capture      = 1;
            last_capture = interval_time ? timestamp : frame_index;
            if (verbose >= 2)
            {
                fprintf(stderr, "[frame capture engaged at %s]\n", time2timecode(timestamp));
            }
        }
        if (capture > 0)
        {
            if (last_decoded + 1 < queue_index - 1)
            {
                if (verbose >= 2)
                {
                    fprintf(stderr, "[decoding %d accumulated packet%s]\n", (queue_index - 1) - (last_decoded + 1), (queue_index - 1) - (last_decoded + 1) > 1 ? "s" : " ");
                }
                for (index = last_decoded + 1; index < queue_index - 1; index ++)
                {
                    TRAP(avcodec_decode_video2(codec_context, source_frame, &decoded, &(queue[index])) < 0, 113);
                }
                last_decoded = index;
            }
            TRAP(avcodec_decode_video2(codec_context, source_frame, &decoded, &(queue[queue_index - 1])) < 0, 114);
            last_decoded = queue_index - 1;
            if (decoded)
            {
                capture = 0;
                generate_path(path, sizeof(path), extracted, timestamp);
                TRAP(!(target = fopen(path, "w")), 115);
                TRAP(sws_scale(scale_context, (const uint8_t **)source_frame->data, source_frame->linesize, 0, codec_context->height, target_frame->data, target_frame->linesize) != codec_context->height, 116);
                TRAP(!(png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL)), 117);
                TRAP(!(png_info = png_create_info_struct(png)), 118);
                png_init_io(png, target);
                png_set_IHDR(png, png_info, target_width, codec_context->height, 8, target_format, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
                png_write_info(png, png_info);
                for (index = 0; index < codec_context->height; index ++)
                {
                    png_write_row(png, target_frame->data[0] + (index * target_frame->linesize[0]));
                }
                png_write_end(png, png_info);
                png_destroy_write_struct(&png, &png_info);
                fclose(target);
                extracted ++;
                if (verbose >= 2)
                {
                    fprintf(stderr, "[frame captured at %s]\n", time2timecode(timestamp));
                }
                if (verbose >= 1)
                {
                    memset(&info, 0, sizeof(info));
                    stat(path, &info);
                    sprintf(size, "%.1fkB", (double)info.st_size / 1024);
                    printf("%s  %s %8.8s\n", path, time2timecode(timestamp), size);
                }
            }
            else
            {
                capture ++;
            }
            TRAP(capture >= 60, 119);
        }
        frame_index ++;
        if ((count && extracted >= count) || (duration && timestamp >= (start + duration + 250)))
        {
            break;
        }
    }
    return extracted ? 0 : 120;
}

// main program entry
int main(int argc, char **argv)
{
    int option;

    static struct option options[] =
    {
        {"help",           0, NULL, 'h'},
        {"version",        0, NULL, 'x'},
        {"verbose",        0, NULL, 'v'},
        {"start",          1, NULL, 's'},
        {"duration",       1, NULL, 'd'},
        {"count",          1, NULL, 'c'},
        {"interval",       1, NULL, 'i'},
        {"keyframes",      0, NULL, 'k'},
        {"keyframes-only", 0, NULL, 'k'},
        {"greyscale",      0, NULL, 'g'},
        {"fingerprint",    0, NULL, 'f'},
        {NULL,             0, NULL, 0}
    };
    while ((option = getopt_long(argc, argv, "hxvs:d:c:i:kgf", options, NULL)) != -1)
    {
        switch (option)
        {
            case 'h':
                fprintf
                (
                    stderr,
                    "usage: %s [options...] <input_file> [<output_format>]\n\n"
                    "-h, --help          this help screen\n"
                    "-x, --version       display version and exit\n"
                    "-v, --verbose       output progress information (can be used multiple times for increased verbosity)\n"
                    "-s, --start         (default: start of input scan in [hh:mm:]ss[.ms] or floating-point seconds format)\n"
                    "-d, --duration      (default: duration of input scan in [hh:mm:]ss[.ms] or floating-point seconds format)\n"
                    "-c, --count         (default: 1)\n"
                    "-i, --interval      (default: 1, i.e. every frame)\n"
                    "-k, --keyframes     extract frames on keyframes only\n"
                    "-g, --greyscale     extract frames in greyscale mode\n"
                    "-f, --fingerprint   extract fingerprinting hashes instead of frames\n\n"
                    "default output format is %%f%%-%%n%%.png (%%f%% is replaced by the input filename (without the extension),\n"
                    "%%n%% is replaced by an incrementing extracted frame index, and %%t%% is replaced by the extracted frame\n"
                    "timecode (in hh:mm:ss.ms format))\n",
                    basename(argv[0])
                );
                return 0;
                break;

            case 'x':
                printf
                (
                    "frmxtract " FRMXTRACT_VERSION " (c) 2007-2021 Pierre-Yves Kerembellec\n"
                    "libavformat  %3d.%2d.%d\n"
                    "libavcodec   %3d.%2d.%d\n"
                    "libswscale   %3d.%2d.%d\n"
                    "libswresample%3d.%2d.%d\n",
                    (avformat_version() >> 16) & 0xff, (avformat_version() >> 8) & 0xff, avformat_version() & 0xff,
                    (avcodec_version() >> 16) & 0xff, (avcodec_version() >> 8) & 0xff, avcodec_version() & 0xff,
                    (swscale_version() >> 16) & 0xff, (swscale_version() >> 8) & 0xff, swscale_version() & 0xff,
                    (swresample_version() >> 16) & 0xff, (swresample_version() >> 8) & 0xff, swresample_version() & 0xff
                );
                return 0;
                break;

            case 'v':
                verbose ++;
                break;

            case 's':
                start = timecode2time(optarg);
                break;

            case 'd':
                duration = timecode2time(optarg);
                break;

            case 'c':
                count = atoi(optarg);
                count = count < 0 ? 0 : count;
                break;

            case 'i':
                if (strchr(optarg, ':') || strchr(optarg, '.'))
                {
                    interval_time = 1;
                    interval      = timecode2time(optarg);
                }
                else
                {
                    interval = atoi(optarg);
                    interval = interval < 1 ? 1 : interval;
                }
                break;

            case 'k':
                keyframes = 1;
                break;

            case 'g':
                greyscale = 1;
                break;

            case 'f':
                fingerprint = 1;
                output = strdup("%f%-fingerprinting.txt");
                break;
        }
    }
    if (optind < argc)
    {
        if (!(input = realpath(argv[optind], NULL)))
        {
            fprintf(stderr, "invalid input file \"%s\"\n", argv[optind]);
            return 1;
        }
        optind ++;
    }
    if (optind < argc)
    {
        output = argv[optind];
    }
    if (!input)
    {
        fprintf(stderr, "missing input file (use --help for detailed usage information)\n");
        return 1;
    }
    return extract();
}

