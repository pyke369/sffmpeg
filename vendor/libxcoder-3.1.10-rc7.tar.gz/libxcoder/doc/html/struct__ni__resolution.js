var struct__ni__resolution =
[
    [ "bit_depth_factor", "struct__ni__resolution.html#af9892833b3c1316652d4b6e45c54ac7c", null ],
    [ "height", "struct__ni__resolution.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
    [ "width", "struct__ni__resolution.html#a395d15e7c2b09961c1bfd1da6179b64c", null ]
];