var struct__ni__ai__config__t =
[
    [ "ui32NetworkBinarySize", "struct__ni__ai__config__t.html#a9dd6f2f0f4091e779d83bec28819cff1", null ],
    [ "ui8Sha256", "struct__ni__ai__config__t.html#ae554a1ff7f84ccfe465244426eef1e3c", null ]
];