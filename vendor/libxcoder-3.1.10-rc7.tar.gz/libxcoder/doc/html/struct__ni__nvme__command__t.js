var struct__ni__nvme__command__t =
[
    [ "cdw10", "struct__ni__nvme__command__t.html#a0244505e23b12babb50fcb2c22fb60f9", null ],
    [ "cdw11", "struct__ni__nvme__command__t.html#a3eeb54f84f99f1bd217809493322a7c9", null ],
    [ "cdw12", "struct__ni__nvme__command__t.html#a0a8e085a116b5b78c95a54873a1401ce", null ],
    [ "cdw13", "struct__ni__nvme__command__t.html#a09453bfb66e62a93d1521be254e3c8ad", null ],
    [ "cdw14", "struct__ni__nvme__command__t.html#aeee003bd7c991c28797b413975ba4e84", null ],
    [ "cdw15", "struct__ni__nvme__command__t.html#a129a86603541eb2540156ee93ef472da", null ],
    [ "cdw2", "struct__ni__nvme__command__t.html#a3a072133e7198facacfc4b9775835168", null ],
    [ "cdw3", "struct__ni__nvme__command__t.html#a147e957bf6d961e3b8188dcf25549277", null ]
];