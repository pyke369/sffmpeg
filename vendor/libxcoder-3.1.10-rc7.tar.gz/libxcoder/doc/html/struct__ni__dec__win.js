var struct__ni__dec__win =
[
    [ "bottom", "struct__ni__dec__win.html#a04c0cf6c92fc4a225e31d4bfd788648e", null ],
    [ "left", "struct__ni__dec__win.html#ab9c055f5477570bf69a93af0b79f9b7d", null ],
    [ "right", "struct__ni__dec__win.html#a0b6b4b6e3552add5576b3a5b626ab099", null ],
    [ "top", "struct__ni__dec__win.html#ad8faa539face43f8178d3c47b07ad1a0", null ]
];