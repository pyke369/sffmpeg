var union__ni__enc__hevc__roi__custom__map =
[
    [ "ctu_coeff_drop", "union__ni__enc__hevc__roi__custom__map.html#a58dd9c64e42bdeb0186545255bc33d26", null ],
    [ "ctu_force_mode", "union__ni__enc__hevc__roi__custom__map.html#a70acc68d51ac3dbac0c691ecc1208088", null ],
    [ "field", "union__ni__enc__hevc__roi__custom__map.html#afa6d565509cfa91d67b8c28bbf113ebf", null ],
    [ "lambda_sad_0", "union__ni__enc__hevc__roi__custom__map.html#aad4f29a4fb65effc3256e7b029c14c99", null ],
    [ "lambda_sad_1", "union__ni__enc__hevc__roi__custom__map.html#aa6d36c2c25548a0fed7c12e61636ecc1", null ],
    [ "lambda_sad_2", "union__ni__enc__hevc__roi__custom__map.html#aa2cc9cb54f3135248001db74111cf5e6", null ],
    [ "lambda_sad_3", "union__ni__enc__hevc__roi__custom__map.html#a9ef140439f012602eba2828f138e7c5b", null ],
    [ "reserved", "union__ni__enc__hevc__roi__custom__map.html#aa43c4c21b173ada1b6b7568956f0d650", null ],
    [ "sub_ctu_qp_0", "union__ni__enc__hevc__roi__custom__map.html#a42ddc41b51a3c53009e1660b7538b626", null ],
    [ "sub_ctu_qp_1", "union__ni__enc__hevc__roi__custom__map.html#ab29af4d01a1bac5823566832deb72789", null ],
    [ "sub_ctu_qp_2", "union__ni__enc__hevc__roi__custom__map.html#af3f4e45286861abe22190a61e5080343", null ],
    [ "sub_ctu_qp_3", "union__ni__enc__hevc__roi__custom__map.html#aa1d1c77a34b127664ba62e62e39c7b1e", null ]
];