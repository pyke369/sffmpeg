var struct__ni__queue__buffer__pool__t =
[
    [ "number_of_buffers", "struct__ni__queue__buffer__pool__t.html#aa395e0bf9ca757f1a1d117c8bc6339fb", null ],
    [ "p_free_head", "struct__ni__queue__buffer__pool__t.html#aa3ecc274504a884f122380925421fb5f", null ],
    [ "p_free_tail", "struct__ni__queue__buffer__pool__t.html#af24079bd64993ac48b294128fb0b05ab", null ],
    [ "p_used_head", "struct__ni__queue__buffer__pool__t.html#ad0808e52a9d7de33af207ab6551cbd3a", null ],
    [ "p_used_tail", "struct__ni__queue__buffer__pool__t.html#a74da1fe945fd27fdfd4d644670f29058", null ]
];