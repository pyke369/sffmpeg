var struct__ni__hrd__params =
[
    [ "au_cpb_removal_delay_length_minus1", "struct__ni__hrd__params.html#abdb19d6c0dd9541a7ee1b63a5dd72cd8", null ],
    [ "au_cpb_removal_delay_minus1", "struct__ni__hrd__params.html#a7ab4281a6b7c18ad74c0d97218a52fed", null ],
    [ "bit_rate_unscale", "struct__ni__hrd__params.html#a51eb931873a50b47cd8932398f2da545", null ],
    [ "cpb_size_unscale", "struct__ni__hrd__params.html#a5b740b23efd5f1b0d28241fd14390ae9", null ],
    [ "dpb_output_delay_length_minus1", "struct__ni__hrd__params.html#aa8b65bcb0cb49aee7bd202fb9b3184ca", null ],
    [ "initial_cpb_removal_delay_length_minus1", "struct__ni__hrd__params.html#a719b8b90fa300763c02381ad3f5e890d", null ]
];