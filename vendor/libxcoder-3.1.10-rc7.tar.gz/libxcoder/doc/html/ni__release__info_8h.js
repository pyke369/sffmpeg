var ni__release__info_8h =
[
    [ "NI_SW_RELEASE_ID", "ni__release__info_8h.html#a30e590b166f7649a065941097f215c58", null ],
    [ "NI_SW_RELEASE_TIME", "ni__release__info_8h.html#ae3a5eadf5a410b4efdb79c032843b8c2", null ]
];