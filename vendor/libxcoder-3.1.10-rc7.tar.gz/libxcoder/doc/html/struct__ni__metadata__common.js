var struct__ni__metadata__common =
[
    [ "crop_bottom", "struct__ni__metadata__common.html#a5f6c40642a18d40affe353d6f67865b9", null ],
    [ "crop_left", "struct__ni__metadata__common.html#ab2cf3e99524a131554c5dacc50b0667d", null ],
    [ "crop_right", "struct__ni__metadata__common.html#a8cd0742377920b93ddb3324a54f3be52", null ],
    [ "crop_top", "struct__ni__metadata__common.html#ac691de506245105fda9ef50b5561da9a", null ],
    [ "frame_height", "struct__ni__metadata__common.html#a54cf73a089957b59b35344c368aa40aa", null ],
    [ "frame_offset", "struct__ni__metadata__common.html#a062e9b64b6ad5813dce0a6b71211d75b", null ],
    [ "frame_tstamp", "struct__ni__metadata__common.html#aa94feb8f8cdb18a946cddfd49e096565", null ],
    [ "frame_type", "struct__ni__metadata__common.html#a08c2fcba966116790baa490880ee7eab", null ],
    [ "frame_width", "struct__ni__metadata__common.html#a6bacf410ac8a6e1ed3030b91b6a3bd96", null ],
    [ "reserved", "struct__ni__metadata__common.html#a5a6ed8c04a3db86066924b1a1bf4dad3", null ],
    [ "ui64_data", "struct__ni__metadata__common.html#a53ca719129ffdfc45083ea2832efdcef", null ]
];