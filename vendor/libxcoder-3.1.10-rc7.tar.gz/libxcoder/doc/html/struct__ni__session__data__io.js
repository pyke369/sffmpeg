var struct__ni__session__data__io =
[
    [ "data", "struct__ni__session__data__io.html#aff8830db5690f81b7dc8ec73b99cb665", null ],
    [ "frame", "struct__ni__session__data__io.html#aea2177bca942215ff8bda12a813375f3", null ],
    [ "packet", "struct__ni__session__data__io.html#a5f6a5891ce9ba762cfb6cd08965e3acb", null ]
];