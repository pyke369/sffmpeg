var structni__decode__cropping__rectangle =
[
    [ "ui16H", "structni__decode__cropping__rectangle.html#a6d59fa8c6522c434269cba1311080a14", null ],
    [ "ui16W", "structni__decode__cropping__rectangle.html#a7449fc5c21341868c2f6d3f41d947e55", null ],
    [ "ui16X", "structni__decode__cropping__rectangle.html#ad130e5208628856c03bb3b0ff7ac7abb", null ],
    [ "ui16Y", "structni__decode__cropping__rectangle.html#aaf99027cc0bc33b03e51e66f893bd67a", null ]
];