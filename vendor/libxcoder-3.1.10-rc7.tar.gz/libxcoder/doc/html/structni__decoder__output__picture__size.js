var structni__decoder__output__picture__size =
[
    [ "ui16Height", "structni__decoder__output__picture__size.html#a4b7a2ecdd9ff6878a33cf3b23d9f0706", null ],
    [ "ui16Width", "structni__decoder__output__picture__size.html#aeae9bc2bd5562d2b45fd2e69773783c4", null ]
];