var struct__ni__instance__mgr__stream__complete =
[
    [ "data_bytes_available", "struct__ni__instance__mgr__stream__complete.html#acc603df09899d8757fe8b69b43d31094", null ],
    [ "is_flushed", "struct__ni__instance__mgr__stream__complete.html#a53f8d848132d487dcb862de1e6ccbac7", null ]
];