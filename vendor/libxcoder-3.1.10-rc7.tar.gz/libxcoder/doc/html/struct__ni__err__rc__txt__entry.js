var struct__ni__err__rc__txt__entry =
[
    [ "rc", "struct__ni__err__rc__txt__entry.html#a23e8bfbce3cdef7f99aa31edbea72128", null ],
    [ "txt", "struct__ni__err__rc__txt__entry.html#afee54b8c48815dbac50e9d3a91f45ea4", null ]
];