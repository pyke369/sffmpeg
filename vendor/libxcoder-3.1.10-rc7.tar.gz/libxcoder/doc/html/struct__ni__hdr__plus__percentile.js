var struct__ni__hdr__plus__percentile =
[
    [ "percentage", "struct__ni__hdr__plus__percentile.html#ac0b53e3a7d1b8de246922a7bc95e1830", null ],
    [ "percentile", "struct__ni__hdr__plus__percentile.html#a6b99c4c4410125679a100eab3e66e61d", null ]
];