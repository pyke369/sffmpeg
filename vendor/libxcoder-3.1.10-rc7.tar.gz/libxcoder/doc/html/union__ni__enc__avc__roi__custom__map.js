var union__ni__enc__avc__roi__custom__map =
[
    [ "field", "union__ni__enc__avc__roi__custom__map.html#a981b31060978733f8803c38291ca25dd", null ],
    [ "mb_force_mode", "union__ni__enc__avc__roi__custom__map.html#ac084e9d66763dc42f3bbf7c03c798216", null ],
    [ "mb_qp", "union__ni__enc__avc__roi__custom__map.html#aa4c41d6e13b838437e8943220c6b6496", null ]
];