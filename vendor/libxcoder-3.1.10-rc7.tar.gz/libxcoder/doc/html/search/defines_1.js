var searchData=
[
  ['atobool_5198',['atobool',['../ni__device__api_8c.html#af34f8d3fdd2937048811842b5b6b6c11',1,'atobool():&#160;ni_device_api.c'],['../ni__device__api_8c.html#af34f8d3fdd2937048811842b5b6b6c11',1,'atobool():&#160;ni_device_api.c'],['../ni__device__api_8c.html#af34f8d3fdd2937048811842b5b6b6c11',1,'atobool():&#160;ni_device_api.c']]],
  ['atof_5199',['atof',['../ni__device__api_8c.html#a06e1f65eaab9f160f4698298bbba44b9',1,'atof():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a06e1f65eaab9f160f4698298bbba44b9',1,'atof():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a06e1f65eaab9f160f4698298bbba44b9',1,'atof():&#160;ni_device_api.c']]],
  ['atoi_5200',['atoi',['../ni__device__api_8c.html#a8bfd5e5c8119fb6f1d6bb0d4278eaa36',1,'atoi():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a8bfd5e5c8119fb6f1d6bb0d4278eaa36',1,'atoi():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a8bfd5e5c8119fb6f1d6bb0d4278eaa36',1,'atoi():&#160;ni_device_api.c']]],
  ['av_5fcodec_5fdefault_5fbitrate_5201',['AV_CODEC_DEFAULT_BITRATE',['../ni__device__api_8h.html#a0bf489e5f6fbc263c4a54d7f4d48a590',1,'ni_device_api.h']]]
];
