var searchData=
[
  ['high_5foffset_5fin_5f4k_5280',['HIGH_OFFSET_IN_4K',['../ni__nvme_8h.html#ae4711dc284a8f8998908b12e921f9b10',1,'ni_nvme.h']]]
];
