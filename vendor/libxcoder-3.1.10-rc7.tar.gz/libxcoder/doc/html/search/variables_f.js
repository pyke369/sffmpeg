var searchData=
[
  ['qlevel_4160',['qlevel',['../struct__ni__encoder__cfg__params.html#aae1ea835cf8bc65ff541df4508b4079c',1,'_ni_encoder_cfg_params']]],
  ['qoffset_4161',['qoffset',['../struct__ni__region__of__interest.html#a0e008666f81cbb88cb9f410e955c6379',1,'_ni_region_of_interest']]],
  ['qp_5ffactor_4162',['qp_factor',['../struct__ni__gop__params.html#a18159f0c8bfc0ef1d4f84c65f4312f7d',1,'_ni_gop_params']]],
  ['qp_5finfo_4163',['qp_info',['../union__ni__enc__quad__roi__custom__map.html#adc3a4236676628de647fe8ec7ce2d784',1,'_ni_enc_quad_roi_custom_map']]],
  ['qp_5foffset_4164',['qp_offset',['../struct__ni__gop__params.html#aaf766de4c5bfa22e8bfdedd60e5e9ce7',1,'_ni_gop_params']]],
  ['quant_5fdata_4165',['quant_data',['../struct__ni__network__layer__params__t.html#aa36991e4054b9d04e7e7c2015fc75c79',1,'_ni_network_layer_params_t']]],
  ['quant_5fformat_4166',['quant_format',['../struct__ni__network__layer__params__t.html#a8ccab6857970d9fba1ab46bc6dd48bee',1,'_ni_network_layer_params_t']]]
];
