var searchData=
[
  ['tensor_5frsrc_3009',['tensor_rsrc',['../structtensor__rsrc.html',1,'']]]
];
