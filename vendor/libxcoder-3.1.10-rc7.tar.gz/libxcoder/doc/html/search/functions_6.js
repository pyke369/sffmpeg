var searchData=
[
  ['is_5fsupported_5fxcoder_3078',['is_supported_xcoder',['../ni__defs_8h.html#aea04b4e3b7f13441b7291dcae8f9ad9d',1,'ni_defs.h']]]
];
