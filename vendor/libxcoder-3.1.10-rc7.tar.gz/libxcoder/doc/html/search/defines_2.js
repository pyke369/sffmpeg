var searchData=
[
  ['br_5fshift_5202',['BR_SHIFT',['../ni__av__codec_8c.html#af94ed018b2c9758988972524b6eef8e7',1,'ni_av_codec.c']]],
  ['buffer_5fpool_5fsz_5fper_5fcontext_5203',['BUFFER_POOL_SZ_PER_CONTEXT',['../ni__util_8h.html#a1248446b5c3f7f900f5c1a5a5889e4c7',1,'ni_util.h']]]
];
