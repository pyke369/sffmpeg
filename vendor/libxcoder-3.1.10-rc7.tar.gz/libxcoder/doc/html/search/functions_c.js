var searchData=
[
  ['scan_5fand_5fclean_5fhwdescriptors_3379',['scan_and_clean_hwdescriptors',['../ni__device__test_8c.html#a59a3f978bc0eb385c1395273c719c027',1,'ni_device_test.c']]],
  ['set_5fdemo_5froi_5fmap_3380',['set_demo_roi_map',['../ni__device__test_8c.html#ab3a6dfc33ae33743bd55f0abfe437aac',1,'ni_device_test.c']]]
];
