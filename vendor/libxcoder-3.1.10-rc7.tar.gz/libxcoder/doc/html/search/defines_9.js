var searchData=
[
  ['identify_5fdevice_5fr_5281',['IDENTIFY_DEVICE_R',['../ni__nvme_8h.html#a7f79f699a0bbccbcea62f631aa414bf0',1,'ni_nvme.h']]],
  ['is_5fxcoder_5fdevice_5ftype_5282',['IS_XCODER_DEVICE_TYPE',['../ni__defs_8h.html#ae17ace12d80eab11bf18f65ebd1f9e21',1,'ni_defs.h']]]
];
