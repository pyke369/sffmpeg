var searchData=
[
  ['file_5fname_5flen_5261',['FILE_NAME_LEN',['../ni__device__test_8h.html#afddfc0468a0fb0d80c116b5e16b9be17',1,'FILE_NAME_LEN():&#160;ni_device_test.h'],['../ni__p2p__test_8c.html#afddfc0468a0fb0d80c116b5e16b9be17',1,'FILE_NAME_LEN():&#160;ni_p2p_test.c']]],
  ['frame_5fchunk_5findex_5fsize_5262',['FRAME_CHUNK_INDEX_SIZE',['../ni__device__api__priv_8h.html#ad1291db1194b6616611f28dd8acea9cf',1,'ni_device_api_priv.h']]]
];
