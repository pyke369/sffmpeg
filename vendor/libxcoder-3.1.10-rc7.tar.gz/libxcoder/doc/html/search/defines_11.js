var searchData=
[
  ['sample_5fsps_5fmax_5fsub_5flayers_5fminus1_5775',['SAMPLE_SPS_MAX_SUB_LAYERS_MINUS1',['../ni__av__codec_8c.html#a60bb9660b8af7e6f6bfadc2f634cad30',1,'ni_av_codec.c']]],
  ['sha256_5fblock_5fsize_5776',['SHA256_BLOCK_SIZE',['../ni__util_8c.html#a9c1fe69ad43d4ca74b84303a0ed64f2f',1,'ni_util.c']]],
  ['sig0_5777',['SIG0',['../ni__util_8c.html#a2f0da11cf6577ba2dd4aea7685d0268e',1,'ni_util.c']]],
  ['sig1_5778',['SIG1',['../ni__util_8c.html#a865de5131d1e990ca62d66220a527d2c',1,'ni_util.c']]],
  ['start_5foffset_5fin_5f4k_5779',['START_OFFSET_IN_4K',['../ni__nvme_8h.html#a960443791c27f77f379e94bc3dcb5770',1,'ni_nvme.h']]]
];
