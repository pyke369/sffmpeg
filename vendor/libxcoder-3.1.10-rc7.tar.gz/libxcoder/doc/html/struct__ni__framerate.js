var struct__ni__framerate =
[
    [ "framerate_denom", "struct__ni__framerate.html#a0a72110806f66e7ad049ae34fd385601", null ],
    [ "framerate_num", "struct__ni__framerate.html#a110c6e1cab8ff2b3676644eed55a57c3", null ]
];