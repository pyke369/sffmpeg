var ni__getopt_8h =
[
    [ "option", "structoption.html", "structoption" ],
    [ "no_argument", "ni__getopt_8h.html#a3bc1d5f667b5b4ca4b4abb685dc874ce", null ],
    [ "optional_argument", "ni__getopt_8h.html#acca06c0a947656bd8b395bf1084ffb72", null ],
    [ "required_argument", "ni__getopt_8h.html#a6ece8d8dfa8378778f7290fdaba5b8bc", null ],
    [ "getopt", "ni__getopt_8h.html#a926f2bd9fa5d4081948136351dc3eb14", null ],
    [ "getopt_long", "ni__getopt_8h.html#a59e6b728611dbb27b8602a35a456e960", null ],
    [ "optarg", "ni__getopt_8h.html#a3d0b3b141e3b527861d0feef93af798e", null ],
    [ "opterr", "ni__getopt_8h.html#ae30f05ee1e2e5652f174a35c7875d25e", null ],
    [ "optind", "ni__getopt_8h.html#ad5e1c16213bbee2d5e8cc363309f418c", null ],
    [ "optopt", "ni__getopt_8h.html#a475b8db98445da73e5f62a1ef6324b95", null ]
];