var struct__ni__device__capability =
[
    [ "device_is_xcoder", "struct__ni__device__capability.html#ad4fed7b2552adb93897ae08ecd3db72f", null ],
    [ "fw_branch_name", "struct__ni__device__capability.html#a91572fb81a332e7d5c82dea0062b60e0", null ],
    [ "fw_build_id", "struct__ni__device__capability.html#a04569ea2f891086c73cd069e6d4ea4d2", null ],
    [ "fw_build_time", "struct__ni__device__capability.html#abce091f9ce105b8be242a2c6c92853ed", null ],
    [ "fw_commit_hash", "struct__ni__device__capability.html#a6332e168616712788c87cda9defcafd0", null ],
    [ "fw_commit_time", "struct__ni__device__capability.html#a415841915f1606c570e5ede8f51cb661", null ],
    [ "fw_rev", "struct__ni__device__capability.html#a5daa56874084593c7531f70708ea304d", null ],
    [ "hw_elements_cnt", "struct__ni__device__capability.html#a96e50bfe16a8a58c521d70354c3dc720", null ],
    [ "model_number", "struct__ni__device__capability.html#a949a451104c5ac6126f6d9bdc5e2a948", null ],
    [ "serial_number", "struct__ni__device__capability.html#a5a7ffa3c5a547506544cfafd1b5039e0", null ],
    [ "xcoder_cnt", "struct__ni__device__capability.html#a3a15acd0d2bbb58c51d27fbd4accc671", null ],
    [ "xcoder_devices", "struct__ni__device__capability.html#a819804d2d3d3fb563024e306bbeedce6", null ],
    [ "xcoder_devices_cnt", "struct__ni__device__capability.html#ac8d7697c7bd6bfb260d422a44d80de68", null ]
];