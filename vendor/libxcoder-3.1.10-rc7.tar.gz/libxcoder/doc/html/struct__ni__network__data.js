var struct__ni__network__data =
[
    [ "input_num", "struct__ni__network__data.html#a3ebd376d25a92b95f6007f9e7638c23f", null ],
    [ "inset", "struct__ni__network__data.html#aa9e62b487c74eb41154e6265aa9b98e2", null ],
    [ "linfo", "struct__ni__network__data.html#a45211861fc0d214506bce4468998b83d", null ],
    [ "offset", "struct__ni__network__data.html#a97bd6c077f3c7769f575b82988b9b668", null ],
    [ "output_num", "struct__ni__network__data.html#abc5810a7a19aa01efbfdd8dfea92b9ca", null ],
    [ "outset", "struct__ni__network__data.html#aa8bcb2a0fd5b069d687a2cf78c622f58", null ]
];