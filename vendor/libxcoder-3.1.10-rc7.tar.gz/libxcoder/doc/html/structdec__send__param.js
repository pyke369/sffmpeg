var structdec__send__param =
[
    [ "input_video_height", "structdec__send__param.html#a3975148b745cef598b45bbd8ac7ac03f", null ],
    [ "input_video_width", "structdec__send__param.html#a80c97c16bb31522d86a7994c903dbe27", null ],
    [ "p_dec_ctx", "structdec__send__param.html#aa876a317f0d32be2ff820fffcb6994a1", null ],
    [ "p_in_pkt", "structdec__send__param.html#a230b83747a4d129d654d76715c59f285", null ],
    [ "p_SPS", "structdec__send__param.html#ae6ecb9c0869937d47bd1e97c8b9bd205", null ],
    [ "p_total_bytes_sent", "structdec__send__param.html#aa22592a5e75bf01d70ca4ee920addf56", null ],
    [ "p_xcodeState", "structdec__send__param.html#a02de17edc0141e70c1b9fe08b7952c1c", null ],
    [ "pkt_size", "structdec__send__param.html#ab4cf1061171e398b48513aa7f163d4d6", null ],
    [ "print_time", "structdec__send__param.html#a128f0a311046a56fe1f73efca649368f", null ]
];