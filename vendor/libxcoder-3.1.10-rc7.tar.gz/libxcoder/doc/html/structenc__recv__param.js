var structenc__recv__param =
[
    [ "mode", "structenc__recv__param.html#a1ea5d0cb93f22f7d0fdf804bd68c3326", null ],
    [ "output_video_height", "structenc__recv__param.html#a986802bad20afdfb36e308f1f34841f9", null ],
    [ "output_video_width", "structenc__recv__param.html#ad15d2463ad113708e6bf825960122baf", null ],
    [ "p_enc_ctx", "structenc__recv__param.html#a0dcef0baa36ca3470b4c561444d1b68c", null ],
    [ "p_file", "structenc__recv__param.html#ac721ca0e57348a01816239cba7c589d1", null ],
    [ "p_hwframe_pool_tracker", "structenc__recv__param.html#a884e42fd0996232670016e306cc957e9", null ],
    [ "p_out_packet", "structenc__recv__param.html#a98bbd37e4ed4d9bdff02bfee7dd4a007", null ],
    [ "p_total_bytes_received", "structenc__recv__param.html#a2443e5b6f82cc9151a9021c909114f33", null ],
    [ "p_xcodeState", "structenc__recv__param.html#a02de17edc0141e70c1b9fe08b7952c1c", null ]
];