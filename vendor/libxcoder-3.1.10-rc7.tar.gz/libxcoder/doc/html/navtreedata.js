/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libxcoder", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"ni__av__codec_8h.html#abc87d560354b4d4ef9f688e9d41d0bf1",
"ni__device__api_8c.html#a3f319c8d2a9750b70eb6a90ede743533",
"ni__device__api_8h.html#a51efd3460e9b85bb197985265d9ab86e",
"ni__device__api_8h.html#ab31b4384df17c8f8449526875f0f26b2",
"ni__device__api__priv_8c.html#aafed6af665c1961f780c92e557d048ae",
"ni__device__test_8c.html#ac4d97bc760865c164710785a4fa570cb",
"ni__nvme_8h.html#ab3a76de5ec80367749775c8b6414dfd8af2151af1c0c4833fbede9edea47323d7",
"ni__util_8c.html#a35e36fc861fad0d9e8a7a7cd9baac3bf",
"struct__ni__decoder__config__t.html#a4a90af4817ede09563c61ea58a55fe2b",
"struct__ni__encoder__config__t.html#a95322a823ea7810a23f556358f376c95",
"struct__ni__hw__capability.html#a680787066b818b6a92b9fa6c34c81911",
"struct__ni__nvme__identity.html#a93f0b4ba85a8ab60c50d7dd8cc7fbec8",
"struct__ni__session__context.html#ae0a00ed98405cc1cf3721b5e060035c7",
"struct_recv_data_struct__.html#aa876a317f0d32be2ff820fffcb6994a1"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';