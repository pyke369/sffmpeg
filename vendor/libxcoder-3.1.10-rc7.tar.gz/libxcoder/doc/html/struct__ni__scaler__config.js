var struct__ni__scaler__config =
[
    [ "filterblit", "struct__ni__scaler__config.html#a1cd24abe2cd987eed6f41ae9676f9481", null ],
    [ "ui32Reserved", "struct__ni__scaler__config.html#a4266c6600943dcc702fa30ea4db4acb5", null ],
    [ "ui8Reserved", "struct__ni__scaler__config.html#ad49104d102c69e5c6792058f679c2f98", null ]
];