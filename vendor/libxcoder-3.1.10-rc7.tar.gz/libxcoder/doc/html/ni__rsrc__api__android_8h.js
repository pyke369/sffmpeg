var ni__rsrc__api__android_8h =
[
    [ "LOG_TAG", "ni__rsrc__api__android_8h.html#a7ce0df38eb467e59f209470c8f5ac4e6", null ],
    [ "ni_rsrc_android_init", "ni__rsrc__api__android_8h.html#a85afce847c76a48c6887a401229d56fc", null ],
    [ "service", "ni__rsrc__api__android_8h.html#a7dcade1f4488ce3e98e318381bbafffc", null ]
];