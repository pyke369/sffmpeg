var structoption =
[
    [ "flag", "structoption.html#a4f1a91bc2d61b12ffb90ff2857d6a4d8", null ],
    [ "has_arg", "structoption.html#afd57c1e532cb0bc43cc77ac7b4dd3350", null ],
    [ "name", "structoption.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "val", "structoption.html#aa0ccb5ee6d882ee3605ff47745c6467b", null ]
];