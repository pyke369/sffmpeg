var ni__log_8c =
[
    [ "arg_to_ni_log_level", "ni__log_8c.html#aa2d3c2d0f8437574aca1cb4f908303ac", null ],
    [ "ff_to_ni_log_level", "ni__log_8c.html#a8db476a4f4a33400621a2355a542425f", null ],
    [ "ni_log", "ni__log_8c.html#ac97d212bfa8e1bf651bd53db800d42f0", null ],
    [ "ni_log_default_callback", "ni__log_8c.html#a06052077fa08dd33f442855db364eb4d", null ],
    [ "ni_log_get_level", "ni__log_8c.html#a16063c2b6a73b704c4c6534ab625246d", null ],
    [ "ni_log_gettimeofday", "ni__log_8c.html#ad0f5987155b1273c15506f94c0930246", null ],
    [ "ni_log_set_callback", "ni__log_8c.html#a8ea7bba32ed03f6e50b7cf425ba74fae", null ],
    [ "ni_log_set_level", "ni__log_8c.html#ac220750a021f3436a99c772e40ac2a22", null ]
];