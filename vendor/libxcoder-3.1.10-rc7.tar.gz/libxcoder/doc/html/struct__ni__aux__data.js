var struct__ni__aux__data =
[
    [ "data", "struct__ni__aux__data.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "size", "struct__ni__aux__data.html#a439227feff9d7f55384e8780cfc2eb82", null ],
    [ "type", "struct__ni__aux__data.html#ace0adf576557694a0108691b4d1089f1", null ]
];