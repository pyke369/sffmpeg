var struct__ni__buf__pool__t =
[
    [ "buf_size", "struct__ni__buf__pool__t.html#a50820ebe716191dad920c497510b3220", null ],
    [ "mutex", "struct__ni__buf__pool__t.html#a1236aa468daefea927f57a8a8e726872", null ],
    [ "number_of_buffers", "struct__ni__buf__pool__t.html#aa395e0bf9ca757f1a1d117c8bc6339fb", null ],
    [ "p_free_head", "struct__ni__buf__pool__t.html#afac175756f5b0760e96c747ed7dbfb67", null ],
    [ "p_free_tail", "struct__ni__buf__pool__t.html#a14b3825d98ee9631ff497526a21928c7", null ],
    [ "p_used_head", "struct__ni__buf__pool__t.html#a16e521d0c3bac629738a9c63bbe1bb17", null ],
    [ "p_used_tail", "struct__ni__buf__pool__t.html#a3ae3b0b8d6ccb0160b7f7e7bcd2ce9d1", null ]
];