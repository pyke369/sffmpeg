var struct__ni__decoder__config__t =
[
    [ "asOutputConfig", "struct__ni__decoder__config__t.html#a4ae9972d39911bcca0caa4c9e3149531", null ],
    [ "fps_denominator", "struct__ni__decoder__config__t.html#a3754a3ed745d94276971604d0bac3f54", null ],
    [ "fps_number", "struct__ni__decoder__config__t.html#a8877d3ae96483c57c5f4bfe3f36b639a", null ],
    [ "ui16MaxSeiDataSize", "struct__ni__decoder__config__t.html#a4a90af4817ede09563c61ea58a55fe2b", null ],
    [ "ui32MaxPktSize", "struct__ni__decoder__config__t.html#a21dfa47a3d3ccbbdf859d69cfa116ded", null ],
    [ "ui8HWFrame", "struct__ni__decoder__config__t.html#a4681365a9ebc211d8290c1e0dda26c54", null ],
    [ "ui8MCMode", "struct__ni__decoder__config__t.html#a834baa6767cf0895d279df8f3c87bc80", null ],
    [ "ui8rsrv", "struct__ni__decoder__config__t.html#a0836c6e4c6e01379c04957ff590bd5b8", null ],
    [ "ui8UduSeiEnabled", "struct__ni__decoder__config__t.html#aa84b76591d46cab8babaf9dad49928ac", null ]
];