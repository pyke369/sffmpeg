var struct__ni__instance__buf__info =
[
    [ "buf_avail_size", "struct__ni__instance__buf__info.html#acb4db5829885430e1e0e49f8b7a4f843", null ],
    [ "hw_inst_ind", "struct__ni__instance__buf__info.html#a50267ba933368eda59974e0db576799e", null ]
];