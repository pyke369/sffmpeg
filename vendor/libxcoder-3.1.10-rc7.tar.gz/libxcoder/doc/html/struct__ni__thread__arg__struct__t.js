var struct__ni__thread__arg__struct__t =
[
    [ "close_thread", "struct__ni__thread__arg__struct__t.html#a0f4ffa073f524464ce90de4e280e7340", null ],
    [ "device_handle", "struct__ni__thread__arg__struct__t.html#a4be6f6176ef1c1f36c9b873e0ac598ee", null ],
    [ "device_type", "struct__ni__thread__arg__struct__t.html#a11b71a6f868cf4482a6cfee4a08d13a0", null ],
    [ "hw_id", "struct__ni__thread__arg__struct__t.html#a0a8a4b1c98c0ad55e5854a002f18caba", null ],
    [ "keep_alive_timeout", "struct__ni__thread__arg__struct__t.html#a33e5d0537c6cd318f10a943dd1a39222", null ],
    [ "p_buffer", "struct__ni__thread__arg__struct__t.html#ac5f1b38d538f42b0a45acd833ea5fc65", null ],
    [ "session_id", "struct__ni__thread__arg__struct__t.html#a946f27f64a6c7500925f6d10c0b007aa", null ],
    [ "session_timestamp", "struct__ni__thread__arg__struct__t.html#ad424e819982703421edfd2abc15a5cb0", null ],
    [ "thread_event_handle", "struct__ni__thread__arg__struct__t.html#a1969e0e4688d5a8367050859e53c7742", null ]
];