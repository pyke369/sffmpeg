var struct_recv_data_struct__ =
[
    [ "arg_height", "struct_recv_data_struct__.html#ae91e67d3ca1ac1094294c59a78135739", null ],
    [ "arg_width", "struct_recv_data_struct__.html#aecc7f5c68a0c2772c369ca1e574a5af0", null ],
    [ "DataSizeLimit", "struct_recv_data_struct__.html#a4aa53b9be31c92ae0c808987161f96d3", null ],
    [ "device_handle", "struct_recv_data_struct__.html#a9f7ec948aaf8e58f5662ee0a5d9072c2", null ],
    [ "fileName", "struct_recv_data_struct__.html#a1d89f9668c6a633415048f1557a27122", null ],
    [ "mode", "struct_recv_data_struct__.html#a1ea5d0cb93f22f7d0fdf804bd68c3326", null ],
    [ "p_dec_ctx", "struct_recv_data_struct__.html#aa876a317f0d32be2ff820fffcb6994a1", null ],
    [ "p_dec_rsrc_ctx", "struct_recv_data_struct__.html#aa1910cac8a0d830cdefe42be0f679340", null ],
    [ "p_enc_ctx", "struct_recv_data_struct__.html#a0dcef0baa36ca3470b4c561444d1b68c", null ],
    [ "p_enc_rsrc_ctx", "struct_recv_data_struct__.html#a09d92e4609148acb4d096280e071c557", null ],
    [ "p_upl_ctx", "struct_recv_data_struct__.html#a11c89761ddce4e6807a4633883893de6", null ],
    [ "p_upl_rsrc_ctx", "struct_recv_data_struct__.html#a2f1264058b319dd9fd6427d5f9d2ed52", null ]
];