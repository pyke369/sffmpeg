var structuploader__param =
[
    [ "input_video_height", "structuploader__param.html#a3975148b745cef598b45bbd8ac7ac03f", null ],
    [ "input_video_width", "structuploader__param.html#a80c97c16bb31522d86a7994c903dbe27", null ],
    [ "p_input_exhausted", "structuploader__param.html#ac987e2d366d6206507cdf6721f6e10cd", null ],
    [ "p_swin_frame", "structuploader__param.html#a19f01bfb4e77aafb3ecc438bdb78d29e", null ],
    [ "p_total_bytes_sent", "structuploader__param.html#aa22592a5e75bf01d70ca4ee920addf56", null ],
    [ "p_upl_ctx", "structuploader__param.html#a11c89761ddce4e6807a4633883893de6", null ],
    [ "pfs", "structuploader__param.html#aa798fe0866f6895d2659e4421a70071e", null ],
    [ "pool_size", "structuploader__param.html#adb1381f06fac90006d98c3c121c6d6c9", null ],
    [ "test_frame_list", "structuploader__param.html#ab9fcb0ebe4cd2a0701aa94e4d1542a1f", null ]
];