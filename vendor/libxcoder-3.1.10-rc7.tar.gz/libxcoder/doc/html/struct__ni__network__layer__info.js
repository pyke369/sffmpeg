var struct__ni__network__layer__info =
[
    [ "in_param", "struct__ni__network__layer__info.html#ad10b4f50805c9f08b3f058ca588288c1", null ],
    [ "out_param", "struct__ni__network__layer__info.html#a0a3b103c15c7bd32cc06f55ff4342858", null ]
];