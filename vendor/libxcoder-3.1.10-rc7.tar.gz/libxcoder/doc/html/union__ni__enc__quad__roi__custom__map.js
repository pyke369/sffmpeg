var union__ni__enc__quad__roi__custom__map =
[
    [ "field", "union__ni__enc__quad__roi__custom__map.html#a63f8b0d73f6e9eb74faeefce661bb14d", null ],
    [ "ipcm_flag", "union__ni__enc__quad__roi__custom__map.html#a103a7980f6dbc13dfc9d7bf021886c5d", null ],
    [ "qp_info", "union__ni__enc__quad__roi__custom__map.html#adc3a4236676628de647fe8ec7ce2d784", null ],
    [ "roiAbsQp_flag", "union__ni__enc__quad__roi__custom__map.html#a126cb6fd472148a96f85aa5d95c0a422", null ]
];