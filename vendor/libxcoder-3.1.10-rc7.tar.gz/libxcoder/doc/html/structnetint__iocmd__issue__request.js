var structnetint__iocmd__issue__request =
[
    [ "data", "structnetint__iocmd__issue__request.html#ac24cea2bfcc927fd29bc74d1086707d8", null ],
    [ "fd", "structnetint__iocmd__issue__request.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "len", "structnetint__iocmd__issue__request.html#a77124bd5f7e31e6fffc19f335da0c23f", null ]
];