---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature request
assignees: ''

---

## System information
- GPU platform enabling for new feature:
- Host machine if it's discrete card:
- libva/libva-utils/gmmlib/media-driver/Media SDK version you are using?
- Are you willing to contribute it?(Yes/No)

## Feature Information
### Describe the feature and expected behavior

### Customer usage and impact for this feature

**Additional context**
Add any other context or screenshots about the feature request here.
