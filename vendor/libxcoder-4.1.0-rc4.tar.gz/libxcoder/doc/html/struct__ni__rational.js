var struct__ni__rational =
[
    [ "den", "struct__ni__rational.html#a15abeb6cd88470d5eee437de7dca138d", null ],
    [ "num", "struct__ni__rational.html#a86cf672daa4e0ad11ad10efc894d19c8", null ]
];