var struct__ni__metadata__enc__bstream =
[
    [ "av1_show_frame", "struct__ni__metadata__enc__bstream.html#a0ea4cf7675c1525f9359de998803e540", null ],
    [ "avg_frame_qp", "struct__ni__metadata__enc__bstream.html#ac6880295b593a6023a5bc6799cf76269", null ],
    [ "frame_cycle", "struct__ni__metadata__enc__bstream.html#abb27cbb435408e09a54001a29f6a938d", null ],
    [ "frame_tstamp", "struct__ni__metadata__enc__bstream.html#aa94feb8f8cdb18a946cddfd49e096565", null ],
    [ "frame_type", "struct__ni__metadata__enc__bstream.html#acf47f9b2777759386086e94ed5962f19", null ],
    [ "metadata_size", "struct__ni__metadata__enc__bstream.html#a53192c5a67e697e614b21c797286d09f", null ],
    [ "recycle_index", "struct__ni__metadata__enc__bstream.html#a15f38ba5121c45f6e98cdf18e929a010", null ],
    [ "reserved", "struct__ni__metadata__enc__bstream.html#aa43c4c21b173ada1b6b7568956f0d650", null ],
    [ "ssimU", "struct__ni__metadata__enc__bstream.html#a88655831c947158a1469826533db2f60", null ],
    [ "ssimV", "struct__ni__metadata__enc__bstream.html#a035d281436a8d0ff9b9cf85c8be59e0b", null ],
    [ "ssimY", "struct__ni__metadata__enc__bstream.html#ad14a28733fddcb06b5c1d4551b068af5", null ]
];