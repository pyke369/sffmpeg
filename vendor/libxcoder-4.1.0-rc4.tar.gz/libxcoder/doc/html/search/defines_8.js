var searchData=
[
  ['hevc_5fmax_5flog2_5fctb_5fsize_6403',['HEVC_MAX_LOG2_CTB_SIZE',['../ni__device__test_8h.html#aca4565c63ab8b5728952e2a4be93e51f',1,'ni_device_test.h']]],
  ['hevc_5fmax_5flong_5fterm_5fref_5fpics_6404',['HEVC_MAX_LONG_TERM_REF_PICS',['../ni__device__test_8h.html#a6667b6b66ab64db1743d01c9411fc1d8',1,'ni_device_test.h']]],
  ['hevc_5fmax_5frefs_6405',['HEVC_MAX_REFS',['../ni__device__test_8h.html#a767007d50d9099435a6aeb7fe8a7aee8',1,'ni_device_test.h']]],
  ['hevc_5fmax_5fshort_5fterm_5fref_5fpic_5fsets_6406',['HEVC_MAX_SHORT_TERM_REF_PIC_SETS',['../ni__device__test_8h.html#a6ad95fcbbd8622a2913f3eba447d9df4',1,'ni_device_test.h']]],
  ['hevc_5fmax_5fsps_5fcount_6407',['HEVC_MAX_SPS_COUNT',['../ni__device__test_8h.html#ad1f0dee717a8909f289d254ac906ac36',1,'ni_device_test.h']]],
  ['hevc_5fmax_5fsub_5flayers_6408',['HEVC_MAX_SUB_LAYERS',['../ni__device__test_8h.html#a1f7be0cc1a44d3bd6b141258997f6195',1,'ni_device_test.h']]],
  ['high_5foffset_5fin_5f4k_6409',['HIGH_OFFSET_IN_4K',['../ni__nvme_8h.html#ae4711dc284a8f8998908b12e921f9b10',1,'ni_nvme.h']]]
];
