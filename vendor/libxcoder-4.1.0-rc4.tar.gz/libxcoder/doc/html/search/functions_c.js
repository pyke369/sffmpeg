var searchData=
[
  ['ontransact_4001',['onTransact',['../class_bn_shared_buffer.html#a5ea9e0aade37166760cb93c75ac91cf8',1,'BnSharedBuffer']]]
];
