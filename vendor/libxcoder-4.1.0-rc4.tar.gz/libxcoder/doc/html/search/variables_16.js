var searchData=
[
  ['xcode_5fload_5fpixel_5462',['xcode_load_pixel',['../struct__ni__device__info.html#af7b563c1eb04ef61577e64a7319c1a77',1,'_ni_device_info']]],
  ['xcoder_5fcnt_5463',['xcoder_cnt',['../struct__ni__device__capability.html#a3a15acd0d2bbb58c51d27fbd4accc671',1,'_ni_device_capability::xcoder_cnt()'],['../struct__ni__nvme__identity.html#ac0dc3c37391875657ea8fb473a7fe7d3',1,'_ni_nvme_identity::xcoder_cnt()'],['../struct__ni__device__queue.html#a645069682219abda6962c0a0d0839c4b',1,'_ni_device_queue::xcoder_cnt()'],['../struct__ni__device.html#acfc5613790f63a6a82434842d4f31ad0',1,'_ni_device::xcoder_cnt()']]],
  ['xcoder_5fdevices_5464',['xcoder_devices',['../struct__ni__device__capability.html#a819804d2d3d3fb563024e306bbeedce6',1,'_ni_device_capability::xcoder_devices()'],['../struct__ni__nvme__identity.html#a1d981ab105e093db64151b799fb455a4',1,'_ni_nvme_identity::xcoder_devices()']]],
  ['xcoder_5fdevices_5fcnt_5465',['xcoder_devices_cnt',['../struct__ni__device__capability.html#ac8d7697c7bd6bfb260d422a44d80de68',1,'_ni_device_capability']]],
  ['xcoder_5fnum_5fdevices_5466',['xcoder_num_devices',['../struct__ni__nvme__identity.html#a6e560dbaf7bf7539748cdc75d6c258cf',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5felements_5467',['xcoder_num_elements',['../struct__ni__nvme__identity.html#a66847fe1b5f3c398d60d26554b186bbb',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5fh264_5fdecoder_5fhw_5468',['xcoder_num_h264_decoder_hw',['../struct__ni__nvme__identity.html#a0bce72c6f2bfe0330620aa64010fa977',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5fh264_5fencoder_5fhw_5469',['xcoder_num_h264_encoder_hw',['../struct__ni__nvme__identity.html#a17cec5244a0f89627a2378f14e545c91',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5fh265_5fdecoder_5fhw_5470',['xcoder_num_h265_decoder_hw',['../struct__ni__nvme__identity.html#a4a970ec6f796425d35308041bac4caf5',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5fh265_5fencoder_5fhw_5471',['xcoder_num_h265_encoder_hw',['../struct__ni__nvme__identity.html#aeb0de0dbf192d147c629a261409e5436',1,'_ni_nvme_identity']]],
  ['xcoder_5fnum_5fhw_5472',['xcoder_num_hw',['../struct__ni__nvme__identity.html#ab1cecc0c28a705ebb24032f2dc731733',1,'_ni_nvme_identity']]],
  ['xcoder_5freserved_5473',['xcoder_reserved',['../struct__ni__nvme__identity.html#a9efc6e252c3c0c1e40c022f964154c8a',1,'_ni_nvme_identity']]],
  ['xcoder_5fstate_5474',['xcoder_state',['../struct__ni__session__context.html#ab853bcac96dea182df3bb8db961c21d1',1,'_ni_session_context']]],
  ['xcoders_5475',['xcoders',['../struct__ni__device__queue.html#a1ad0b23706e102816b97fc292aa50439',1,'_ni_device_queue::xcoders()'],['../struct__ni__device.html#ab793a8ae2c012739a33db731b90c02eb',1,'_ni_device::xcoders()']]]
];
