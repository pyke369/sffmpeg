var searchData=
[
  ['open_5fadd_5fcodec_6903',['OPEN_ADD_CODEC',['../ni__nvme_8h.html#ac65997c0a56b8397e0f86f9cab4f7cf0',1,'ni_nvme.h']]],
  ['open_5fget_5fsid_5fr_6904',['OPEN_GET_SID_R',['../ni__nvme_8h.html#a9ff0638ff78cead4eae49ca782719504',1,'ni_nvme.h']]],
  ['open_5fsession_5fcodec_6905',['OPEN_SESSION_CODEC',['../ni__nvme_8h.html#ae69fb111f39c152ba693b4eb363f5e9c',1,'ni_nvme.h']]],
  ['open_5fsession_5fw_6906',['OPEN_SESSION_W',['../ni__nvme_8h.html#af7e81c5f4ba4ab8c436e5c2a054d4cb6',1,'ni_nvme.h']]],
  ['opt_6907',['OPT',['../ni__device__api_8c.html#a1bc17a7d89b4055956c8495c71e9c7e2',1,'OPT():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a1bc17a7d89b4055956c8495c71e9c7e2',1,'OPT():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a1bc17a7d89b4055956c8495c71e9c7e2',1,'OPT():&#160;ni_device_api.c']]],
  ['opt2_6908',['OPT2',['../ni__device__api_8c.html#a48f37c2517b9de535c2e7cf19ee2e6e4',1,'OPT2():&#160;ni_device_api.c'],['../ni__device__api_8c.html#a48f37c2517b9de535c2e7cf19ee2e6e4',1,'OPT2():&#160;ni_device_api.c']]],
  ['optional_5fargument_6909',['optional_argument',['../ni__getopt_8h.html#acca06c0a947656bd8b395bf1084ffb72',1,'ni_getopt.h']]]
];
