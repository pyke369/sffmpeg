var searchData=
[
  ['calc_5fframe_5fbuffer_5fsize_3667',['calc_frame_buffer_size',['../ni__device__test_8c.html#a10e629ef99ad44bcec61a80e3e4b30c9',1,'ni_device_test.c']]],
  ['change_5flog_5flevel_3668',['change_log_level',['../test__rsrc__api_8c.html#a4a2814ce7b04a2f0b2e8f66430d4f9d8',1,'test_rsrc_api.c']]],
  ['compareint32_5ft_3669',['compareInt32_t',['../ni__rsrc__mon_8c.html#a1f3771daa6915c0639f3f652936f5cf9',1,'ni_rsrc_mon.c']]]
];
