var searchData=
[
  ['slice_5ftype_5ft_5780',['slice_type_t',['../ni__av__codec_8c.html#adfb33261b950a7267523fd72b32a3199',1,'ni_av_codec.c']]]
];
