var searchData=
[
  ['inst_5fbuf_5finfo_5fr_5facquire_5866',['INST_BUF_INFO_R_ACQUIRE',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288a16974f9dcdc03b3d84ed5ebb84a5dc93',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fread_5867',['INST_BUF_INFO_RW_READ',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288a0b62444bee55d5dcc2a3778e1db35eac',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fread_5fbusy_5868',['INST_BUF_INFO_RW_READ_BUSY',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288af535a04bed40f1ea65d808b1d17160a7',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fupload_5869',['INST_BUF_INFO_RW_UPLOAD',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288a88c263271779988ffe7de679e4d40585',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fwrite_5870',['INST_BUF_INFO_RW_WRITE',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288a00d27309a808b1b501d42fc2d645378c',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fwrite_5fbusy_5871',['INST_BUF_INFO_RW_WRITE_BUSY',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288a5118ca8e9958a6f6cc2a22385735a673',1,'ni_device_api_priv.h']]],
  ['inst_5fbuf_5finfo_5frw_5fwrite_5fby_5fep_5872',['INST_BUF_INFO_RW_WRITE_BY_EP',['../ni__device__api__priv_8h.html#ad6b3dca888f3531ef6bad605adbff288aa8bbcda5ef3c8a0c007c3b7078bd0d0d',1,'ni_device_api_priv.h']]]
];
