var searchData=
[
  ['tensor_5frsrc_3618',['tensor_rsrc',['../structtensor__rsrc.html',1,'']]]
];
