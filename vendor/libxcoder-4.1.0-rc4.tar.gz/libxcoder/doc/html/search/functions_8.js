var searchData=
[
  ['implement_5fmeta_5finterface_3706',['IMPLEMENT_META_INTERFACE',['../_i_shared_buffer_8cpp.html#a910977527a5401ebc3206a58447a9c3b',1,'ISharedBuffer.cpp']]],
  ['init_5fscaler_5fparams_3707',['init_scaler_params',['../ni__device__test_8c.html#a3f1756c460f3fd16d139a1740ba05b91',1,'ni_device_test.c']]],
  ['is_5fsupported_5fxcoder_3708',['is_supported_xcoder',['../ni__defs_8h.html#aea04b4e3b7f13441b7291dcae8f9ad9d',1,'ni_defs.h']]]
];
