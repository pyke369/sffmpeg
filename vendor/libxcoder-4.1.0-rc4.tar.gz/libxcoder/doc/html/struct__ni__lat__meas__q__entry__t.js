var struct__ni__lat__meas__q__entry__t =
[
    [ "abs_timenano", "struct__ni__lat__meas__q__entry__t.html#a651bb2d7bbd05aec610858e3020553ae", null ],
    [ "ts_time", "struct__ni__lat__meas__q__entry__t.html#a058296907d5399e6ce5482aa713f14d9", null ]
];