var struct__ni__custom__sei__set =
[
    [ "count", "struct__ni__custom__sei__set.html#ad43c3812e6d13e0518d9f8b8f463ffcf", null ],
    [ "custom_sei", "struct__ni__custom__sei__set.html#a7fa35888f6d7a395cf22365e344c16af", null ]
];