var ni__p2p__ioctl_8h =
[
    [ "netint_iocmd_export_dmabuf", "structnetint__iocmd__export__dmabuf.html", "structnetint__iocmd__export__dmabuf" ],
    [ "netint_iocmd_issue_request", "structnetint__iocmd__issue__request.html", "structnetint__iocmd__issue__request" ],
    [ "netint_iocmd_attach_rfence", "structnetint__iocmd__attach__rfence.html", "structnetint__iocmd__attach__rfence" ],
    [ "netint_iocmd_signal_rfence", "structnetint__iocmd__signal__rfence.html", "structnetint__iocmd__signal__rfence" ],
    [ "NETINT_IOCTL_ATTACH_RFENCE", "ni__p2p__ioctl_8h.html#a1998ef97170001fa10cf4be16c39ea2f", null ],
    [ "NETINT_IOCTL_EXPORT_DMABUF", "ni__p2p__ioctl_8h.html#a3ac3fad7542a17465c311f2f9283d239", null ],
    [ "NETINT_IOCTL_ID", "ni__p2p__ioctl_8h.html#a76fc962b591ae73b611b740f3b95e08e", null ],
    [ "NETINT_IOCTL_ISSUE_REQ", "ni__p2p__ioctl_8h.html#a8f569949714eecc013dd5a5fecbcd20b", null ],
    [ "NETINT_IOCTL_SIGNAL_RFENCE", "ni__p2p__ioctl_8h.html#a877189703fb08503d5e99242bbeb1ec4", null ],
    [ "NI_DMABUF_READ_FENCE", "ni__p2p__ioctl_8h.html#ad6a0ce949bad6cb64aadb16116dec90a", null ],
    [ "NI_DMABUF_SYNC_FILE_IN_FENCE", "ni__p2p__ioctl_8h.html#a94e579a93d192d45fb95eb8bb1236d97", null ],
    [ "NI_DMABUF_SYNC_FILE_OUT_FENCE", "ni__p2p__ioctl_8h.html#a9a433092a71474f2c323ca2efe50e255", null ],
    [ "NI_DMABUF_READ_FROM_DEVICE", "ni__p2p__ioctl_8h.html#a39fca1837c5ce7715cbf571669660c13aabeeef0e94e956b57450c209d036b3c5", null ],
    [ "NI_DMABUF_WRITE_TO_DEVICE", "ni__p2p__ioctl_8h.html#a39fca1837c5ce7715cbf571669660c13a7fb0ef112afe0dfc6fb4cfc1910ba5c4", null ]
];