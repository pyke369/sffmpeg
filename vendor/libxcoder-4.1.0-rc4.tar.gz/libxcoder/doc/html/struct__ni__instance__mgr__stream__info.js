var struct__ni__instance__mgr__stream__info =
[
    [ "frame_rate", "struct__ni__instance__mgr__stream__info.html#a5cbd910f7c047f675e5022a0fedbfb88", null ],
    [ "is_flushed", "struct__ni__instance__mgr__stream__info.html#a53f8d848132d487dcb862de1e6ccbac7", null ],
    [ "picture_height", "struct__ni__instance__mgr__stream__info.html#a6bd8a255766c1b1b0c3cc01169b673a1", null ],
    [ "picture_width", "struct__ni__instance__mgr__stream__info.html#ae92adc42ff99cfbf1d1eae8b13d7bd75", null ],
    [ "pix_format", "struct__ni__instance__mgr__stream__info.html#ab1f5db47debf2cd5b160ba00f233e904", null ],
    [ "reserve", "struct__ni__instance__mgr__stream__info.html#ac6c17ab632a9c78bc9fa846e9baeea7b", null ],
    [ "reserved", "struct__ni__instance__mgr__stream__info.html#a3487d1b3d31184fad96378db18b67ea3", null ],
    [ "transfer_frame_height", "struct__ni__instance__mgr__stream__info.html#a2be6d5d7421790b53b5d44d3723603cb", null ],
    [ "transfer_frame_stride", "struct__ni__instance__mgr__stream__info.html#a88f492cb9639064c9157acc00e7e47ff", null ]
];