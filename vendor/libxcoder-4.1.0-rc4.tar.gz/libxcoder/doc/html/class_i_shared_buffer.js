var class_i_shared_buffer =
[
    [ "DECLARE_META_INTERFACE", "class_i_shared_buffer.html#aec066c21376cca3bacc5d5f922c87b0e", null ],
    [ "getFd", "class_i_shared_buffer.html#a8c6d2a6c1825a5e2f1d30f52f48d2043", null ],
    [ "setFd", "class_i_shared_buffer.html#a375b01c3ccca5ad26bdd60dbe732d087", null ]
];