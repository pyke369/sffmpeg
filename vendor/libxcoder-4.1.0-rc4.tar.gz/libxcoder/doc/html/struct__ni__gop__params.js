var struct__ni__gop__params =
[
    [ "num_ref_pics", "struct__ni__gop__params.html#a0e767e1f117201264555ef372047acb7", null ],
    [ "pic_type", "struct__ni__gop__params.html#adda1e53e75bb6a22b7b63a8972f3403a", null ],
    [ "poc_offset", "struct__ni__gop__params.html#a78bb26bb9ca9c0b36f464ccecd5a2082", null ],
    [ "qp_factor", "struct__ni__gop__params.html#a18159f0c8bfc0ef1d4f84c65f4312f7d", null ],
    [ "qp_offset", "struct__ni__gop__params.html#aaf766de4c5bfa22e8bfdedd60e5e9ce7", null ],
    [ "rps", "struct__ni__gop__params.html#ae9da106f1e7465440d7027dec02395eb", null ],
    [ "temporal_id", "struct__ni__gop__params.html#ac5ddfc6b85761655c1f00e9364aa9f0f", null ]
];