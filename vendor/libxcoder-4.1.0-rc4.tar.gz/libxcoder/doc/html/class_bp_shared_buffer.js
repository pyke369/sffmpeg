var class_bp_shared_buffer =
[
    [ "BpSharedBuffer", "class_bp_shared_buffer.html#a542e40e192d3afb25254e2042e05e752", null ],
    [ "getFd", "class_bp_shared_buffer.html#a25a0e511ab81c50a5050e8f5e37fb058", null ],
    [ "setFd", "class_bp_shared_buffer.html#a86a4017dadeb95ad4721878d1d4f8b7f", null ]
];