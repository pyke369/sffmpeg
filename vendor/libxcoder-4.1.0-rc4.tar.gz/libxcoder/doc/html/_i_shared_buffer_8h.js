var _i_shared_buffer_8h =
[
    [ "ISharedBuffer", "class_i_shared_buffer.html", "class_i_shared_buffer" ],
    [ "BnSharedBuffer", "class_bn_shared_buffer.html", "class_bn_shared_buffer" ],
    [ "SHARED_BUFFER_SERVICE", "_i_shared_buffer_8h.html#a0731860bf51e4fea25f65f784d8ff00c", null ],
    [ "STR_BUFFER_LEN", "_i_shared_buffer_8h.html#aaba93a4db475db0253cf8e1ce05151cd", null ]
];