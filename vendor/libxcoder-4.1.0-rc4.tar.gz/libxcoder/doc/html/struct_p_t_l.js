var struct_p_t_l =
[
    [ "general_ptl", "struct_p_t_l.html#ad68e55dd42e1b84928b0b89fd92110ea", null ],
    [ "sub_layer_level_present_flag", "struct_p_t_l.html#a59d04fdcbe89d38e296789e23ac36e95", null ],
    [ "sub_layer_profile_present_flag", "struct_p_t_l.html#a41f8c22fbbf12fc5bb1c75b03382a4dd", null ],
    [ "sub_layer_ptl", "struct_p_t_l.html#a8a3eeb7408288543b298dd03c6cb7b4c", null ]
];