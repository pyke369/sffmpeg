var structni__data__chunk__t =
[
    [ "data", "structni__data__chunk__t.html#aee329df4002c289969d4443c4a0bc7bd", null ],
    [ "len", "structni__data__chunk__t.html#a96bbf959016e4411c9e6b9812a8be60a", null ],
    [ "next", "structni__data__chunk__t.html#a5785b5ee75ebbcba6191a220786c85f5", null ]
];