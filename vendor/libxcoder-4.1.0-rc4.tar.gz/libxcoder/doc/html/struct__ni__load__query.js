var struct__ni__load__query =
[
    [ "active_hwuploaders", "struct__ni__load__query.html#abdf3b05ab6033a31a931d3a2a4d7037d", null ],
    [ "context_status", "struct__ni__load__query.html#a509862645541f2af277e823c6bac3274", null ],
    [ "current_load", "struct__ni__load__query.html#aa202e51accad981236be649818f2d8c3", null ],
    [ "fw_model_load", "struct__ni__load__query.html#a6e8ba5bf553e52fd32116f7402a8ae66", null ],
    [ "fw_p2p_mem_usage", "struct__ni__load__query.html#a86117508deb89adfa5e62c5378386bdb", null ],
    [ "fw_share_mem_usage", "struct__ni__load__query.html#a218f6c73fd5a7e4fc05a38bdd9fdaf1f", null ],
    [ "fw_video_mem_usage", "struct__ni__load__query.html#ac6d5d2461fe3ddc34607c0c1a0bbfee5", null ],
    [ "total_contexts", "struct__ni__load__query.html#aa6bfe140287adba7005862a782545669", null ]
];