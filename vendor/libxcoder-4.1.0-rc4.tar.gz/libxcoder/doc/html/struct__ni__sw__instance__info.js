var struct__ni__sw__instance__info =
[
    [ "codec", "struct__ni__sw__instance__info.html#a5d523c13e7580783149de7a0685c2f0b", null ],
    [ "fps", "struct__ni__sw__instance__info.html#a45b67662d620a977a2cfe519f7ab6273", null ],
    [ "height", "struct__ni__sw__instance__info.html#ad12fc34ce789bce6c8a05d8a17138534", null ],
    [ "id", "struct__ni__sw__instance__info.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "status", "struct__ni__sw__instance__info.html#a1edc0e5686dc061d581baf18b9afcefd", null ],
    [ "width", "struct__ni__sw__instance__info.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];