var struct__ni__decoder__input__params__t =
[
    [ "cr_expr", "struct__ni__decoder__input__params__t.html#a145006a49f452ff11b0d3efeab788b0a", null ],
    [ "crop_mode", "struct__ni__decoder__input__params__t.html#adddb15a34e3606b4e0eca08db5f18126", null ],
    [ "crop_whxy", "struct__ni__decoder__input__params__t.html#ae348912e3303ae9679e8d812c6b457c7", null ],
    [ "custom_sei_passthru", "struct__ni__decoder__input__params__t.html#a0ba3c73d44d1efc26ac4b2ad8c2dd131", null ],
    [ "decoder_low_delay", "struct__ni__decoder__input__params__t.html#a5eea93bf595896d0ca7ea95d17076734", null ],
    [ "enable_out1", "struct__ni__decoder__input__params__t.html#ae8a2cbd486fc640cc143ff1a452b3891", null ],
    [ "enable_out2", "struct__ni__decoder__input__params__t.html#a1f816a09f20a0787eee05a10fb4009d3", null ],
    [ "enable_user_data_sei_passthru", "struct__ni__decoder__input__params__t.html#a0b6f00e07b001c23ab2f901743dd737f", null ],
    [ "force_8_bit", "struct__ni__decoder__input__params__t.html#add8c5d1aa963e9d5ce7b353a47cb5812", null ],
    [ "hwframes", "struct__ni__decoder__input__params__t.html#a46f41eb5ee344ee723074269894a71bb", null ],
    [ "keep_alive_timeout", "struct__ni__decoder__input__params__t.html#afd09424575573de1308e3ba45c511dbe", null ],
    [ "mcmode", "struct__ni__decoder__input__params__t.html#a6af68591e249645f847ca91543997c18", null ],
    [ "nb_save_pkt", "struct__ni__decoder__input__params__t.html#a21863d72b1601d2650a50b5e907038c0", null ],
    [ "sc_expr", "struct__ni__decoder__input__params__t.html#af2bb3b67c5559504995ab5ed5907273e", null ],
    [ "scale_wh", "struct__ni__decoder__input__params__t.html#a354b4ccb06d252fe0463812436e04fd3", null ],
    [ "semi_planar", "struct__ni__decoder__input__params__t.html#a9b556b67335a325f16b3d48324c42aa8", null ]
];