var struct__ni__device__context =
[
    [ "lock", "struct__ni__device__context.html#ad70c9254e2a51831bfd8b769d977a6a9", null ],
    [ "p_device_info", "struct__ni__device__context.html#a68d7bd7ca36633b8821d38d967baf70e", null ],
    [ "shm_name", "struct__ni__device__context.html#ada1a7b89b3d42ee9de8937df9ee48e12", null ]
];