var struct__ni__queue__node__t =
[
    [ "checkout_timestamp", "struct__ni__queue__node__t.html#acb867aea9a0784db86afb340543771f6", null ],
    [ "frame_info", "struct__ni__queue__node__t.html#a4089388889bdd62db8384f3d4f628c30", null ],
    [ "p_next", "struct__ni__queue__node__t.html#afd8010f01884d7c0dc014cb57480149b", null ],
    [ "p_next_buffer", "struct__ni__queue__node__t.html#ae3fb33f413180540c3055673f1b4455d", null ],
    [ "p_prev", "struct__ni__queue__node__t.html#afe8e8271ea7d7114eab3e1c041f3a4f6", null ],
    [ "p_previous_buffer", "struct__ni__queue__node__t.html#a589649d11ded883cfcaaca52da500130", null ],
    [ "timestamp", "struct__ni__queue__node__t.html#a465bef81f6478756e5443025b1f2ddfa", null ]
];