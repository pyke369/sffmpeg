var struct__ni__network__buffer =
[
    [ "ui32Address", "struct__ni__network__buffer.html#a2292d4171a6024f0fc314abf23c49574", null ]
];