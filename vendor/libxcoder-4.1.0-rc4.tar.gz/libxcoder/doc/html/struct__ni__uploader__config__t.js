var struct__ni__uploader__config__t =
[
    [ "ui16picHeight", "struct__ni__uploader__config__t.html#a5320083ab12de6c3bad50a36f757f874", null ],
    [ "ui16picWidth", "struct__ni__uploader__config__t.html#a1a63d1afbb08b86703c961f1c644cfca", null ],
    [ "ui8PixelFormat", "struct__ni__uploader__config__t.html#a0f81617e929fe052796cc55b25be24bb", null ],
    [ "ui8Pool", "struct__ni__uploader__config__t.html#a624b8ac8a6f3bc3dd75e79a31eb1d4e9", null ],
    [ "ui8poolSize", "struct__ni__uploader__config__t.html#a25130ead75b480e649734a3816d88091", null ],
    [ "ui8rsvd", "struct__ni__uploader__config__t.html#a62cf3eae477844cfcc971204e5bd1b06", null ]
];