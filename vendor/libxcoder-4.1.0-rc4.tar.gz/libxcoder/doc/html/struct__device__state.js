var struct__device__state =
[
    [ "dec_eos_received", "struct__device__state.html#aca8abc0ddb0c7d9979f8723023fa4d22", null ],
    [ "dec_eos_sent", "struct__device__state.html#ab60de99239eeb9c603475aab28213db7", null ],
    [ "enc_eos_received", "struct__device__state.html#adc5f41024284d5170e32530ca33cd02b", null ],
    [ "enc_eos_sent", "struct__device__state.html#a6741315a1eba7b630bc59a4b2cb72d3b", null ],
    [ "enc_seq_change", "struct__device__state.html#a231b0ebfe39442facf521c958114d2f2", null ]
];