var struct__ni__session__config__rw =
[
    [ "uHWAccessField", "struct__ni__session__config__rw.html#a4a05e72eef99fae0f216d10454cb23bc", null ],
    [ "ui16ReadFrameId", "struct__ni__session__config__rw.html#adb93d5935cbc6caf458c26895d07c767", null ],
    [ "ui16WriteFrameId", "struct__ni__session__config__rw.html#a34a27a6a952f85426491413158953f3a", null ],
    [ "ui8Enable", "struct__ni__session__config__rw.html#a4764439ef59460f32f098aff20309404", null ],
    [ "ui8HWAccess", "struct__ni__session__config__rw.html#aa34c373cc0af71f56c5365adb60c04c8", null ]
];