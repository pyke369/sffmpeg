var struct__ni__context__query =
[
    [ "codec_format", "struct__ni__context__query.html#a6972a0220282afb0857578bfe45fc53a", null ],
    [ "context_id", "struct__ni__context__query.html#a01310ac31e1626aab8d73ec86158f340", null ],
    [ "context_status", "struct__ni__context__query.html#ad153b73c17173fc602b725f30d028903", null ],
    [ "fps", "struct__ni__context__query.html#a129745a75be674a0496ddd992bc3b22b", null ],
    [ "reserved", "struct__ni__context__query.html#aa43c4c21b173ada1b6b7568956f0d650", null ],
    [ "video_height", "struct__ni__context__query.html#af65e7328fad30f40770959957538da7c", null ],
    [ "video_width", "struct__ni__context__query.html#a94c61f9d8155afb285177936e9fa30ce", null ]
];