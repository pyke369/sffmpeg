var structnetint__iocmd__export__dmabuf =
[
    [ "bar", "structnetint__iocmd__export__dmabuf.html#a2df8914184cddeed49ac0b633472d973", null ],
    [ "bus", "structnetint__iocmd__export__dmabuf.html#ade2026c62118b7cc816e3b19c631fad8", null ],
    [ "dev", "structnetint__iocmd__export__dmabuf.html#a22c99b5ae74d0e3dcf126f0d950538e4", null ],
    [ "domain", "structnetint__iocmd__export__dmabuf.html#a1e8a62bcb89bd75956f39f6d251fd6e4", null ],
    [ "fd", "structnetint__iocmd__export__dmabuf.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "flags", "structnetint__iocmd__export__dmabuf.html#ac92588540e8c1d014a08cd8a45462b19", null ],
    [ "fn", "structnetint__iocmd__export__dmabuf.html#ad55146f603688f418cd68140c9b02cd3", null ],
    [ "length", "structnetint__iocmd__export__dmabuf.html#a9ee64c7b918513891b3834b93ad0e501", null ],
    [ "offset", "structnetint__iocmd__export__dmabuf.html#ac1369a1f209735864674d22517edfa76", null ]
];