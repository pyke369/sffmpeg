var struct__ni__custom__sei =
[
    [ "data", "struct__ni__custom__sei.html#ac50e4c5c7bbcd3eba0a263a8646cad01", null ],
    [ "location", "struct__ni__custom__sei.html#a69bb1f7a83496dda0e4ba4781fec4903", null ],
    [ "size", "struct__ni__custom__sei.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "type", "struct__ni__custom__sei.html#a1d127017fb298b889f4ba24752d08b8e", null ]
];