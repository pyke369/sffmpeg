var struct__ni__nvme__write__complete__dw0__t =
[
    [ "available_space", "struct__ni__nvme__write__complete__dw0__t.html#a3bdaf39d5557532933d970bc43c25d14", null ],
    [ "frame_index", "struct__ni__nvme__write__complete__dw0__t.html#a05f60adb7ca73495905c236f23d474d6", null ],
    [ "reserved", "struct__ni__nvme__write__complete__dw0__t.html#aa43c4c21b173ada1b6b7568956f0d650", null ]
];