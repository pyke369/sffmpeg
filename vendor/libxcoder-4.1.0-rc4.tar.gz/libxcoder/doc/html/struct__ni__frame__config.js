var struct__ni__frame__config =
[
    [ "frame_index", "struct__ni__frame__config.html#a17243dd1c599a2737073b0994b8cd38f", null ],
    [ "options", "struct__ni__frame__config.html#af86bc430f5b8c737809e0e3baae4ecea", null ],
    [ "orientation", "struct__ni__frame__config.html#ab97b9072b1fb9c4a2e6d5b134dff70e3", null ],
    [ "output_index", "struct__ni__frame__config.html#ab424dfb20efc55b2e94b87e3bb3fdc52", null ],
    [ "picture_format", "struct__ni__frame__config.html#a67b671e1cce12e55c159f32e74f6c6b6", null ],
    [ "picture_height", "struct__ni__frame__config.html#a6bd8a255766c1b1b0c3cc01169b673a1", null ],
    [ "picture_width", "struct__ni__frame__config.html#ae92adc42ff99cfbf1d1eae8b13d7bd75", null ],
    [ "rectangle_height", "struct__ni__frame__config.html#a3dc1aaa8803aef750a3bb098f129352c", null ],
    [ "rectangle_width", "struct__ni__frame__config.html#ae24ca468d06f64a24d92f538ab0c8569", null ],
    [ "rectangle_x", "struct__ni__frame__config.html#a72c6d2810d00167ac4136158ce6b7109", null ],
    [ "rectangle_y", "struct__ni__frame__config.html#af523dd1939f6e4c1cf01f339ce902211", null ],
    [ "rgba_color", "struct__ni__frame__config.html#ab958277a43902cc0bdbe6793038be162", null ],
    [ "session_id", "struct__ni__frame__config.html#aa4dda8fb1660bbd71c91ba40a7fda4e9", null ]
];