var struct__ni__metadata__enc__bstream__rev61 =
[
    [ "av1_show_frame", "struct__ni__metadata__enc__bstream__rev61.html#a0ea4cf7675c1525f9359de998803e540", null ],
    [ "avg_frame_qp", "struct__ni__metadata__enc__bstream__rev61.html#ac6880295b593a6023a5bc6799cf76269", null ],
    [ "bs_frame_size", "struct__ni__metadata__enc__bstream__rev61.html#a601183e793f53cdcb0d96113c59f3b08", null ],
    [ "frame_cycle", "struct__ni__metadata__enc__bstream__rev61.html#abb27cbb435408e09a54001a29f6a938d", null ],
    [ "frame_tstamp", "struct__ni__metadata__enc__bstream__rev61.html#aa94feb8f8cdb18a946cddfd49e096565", null ],
    [ "frame_type", "struct__ni__metadata__enc__bstream__rev61.html#acf47f9b2777759386086e94ed5962f19", null ],
    [ "recycle_index", "struct__ni__metadata__enc__bstream__rev61.html#a15f38ba5121c45f6e98cdf18e929a010", null ]
];