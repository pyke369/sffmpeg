var struct__ni__queue__t =
[
    [ "count", "struct__ni__queue__t.html#a86988a65e0d3ece7990c032c159786d6", null ],
    [ "name", "struct__ni__queue__t.html#abc1e86d7c344fe34ff09e72d4595ab7e", null ],
    [ "p_first", "struct__ni__queue__t.html#a768ec5faf7b000ebcdfb3a105f5938a2", null ],
    [ "p_last", "struct__ni__queue__t.html#a337ed7e32c929deb2cc1dc12f52f21b8", null ]
];