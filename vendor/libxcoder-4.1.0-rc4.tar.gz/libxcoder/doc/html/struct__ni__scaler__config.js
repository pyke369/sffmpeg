var struct__ni__scaler__config =
[
    [ "filterblit", "struct__ni__scaler__config.html#a1cd24abe2cd987eed6f41ae9676f9481", null ],
    [ "numInputs", "struct__ni__scaler__config.html#ae68e05f2c699126678d94b35b4701cd7", null ],
    [ "ui32Reserved", "struct__ni__scaler__config.html#a4266c6600943dcc702fa30ea4db4acb5", null ],
    [ "ui8Reserved", "struct__ni__scaler__config.html#a5ecb655d79ee8a5c899477732f6f38f2", null ]
];