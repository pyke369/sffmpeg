var struct__ni__device =
[
    [ "xcoder_cnt", "struct__ni__device.html#acfc5613790f63a6a82434842d4f31ad0", null ],
    [ "xcoders", "struct__ni__device.html#ab793a8ae2c012739a33db731b90c02eb", null ]
];