var struct__ni__metadata__dec__frame =
[
    [ "first_sei_header", "struct__ni__metadata__dec__frame.html#aba9560c76f516d68a748e8bd197ca963", null ],
    [ "hwdesc", "struct__ni__metadata__dec__frame.html#a72cd4065610e5e849c8bad1fcece8337", null ],
    [ "metadata_common", "struct__ni__metadata__dec__frame.html#ad724728890741c81632922a3c9f307f0", null ],
    [ "sei_header", "struct__ni__metadata__dec__frame.html#a5549610d442d45b1e72671f9f81417d3", null ],
    [ "sei_number", "struct__ni__metadata__dec__frame.html#ac401d6144f72b550559fab496ae62e7f", null ],
    [ "sei_size", "struct__ni__metadata__dec__frame.html#a6011b5a0baf165166c1ed7fcbd8a0386", null ]
];