/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libxcoder", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_i_shared_buffer_8cpp.html",
"ni__av__codec_8h.html#a2385e6e81668e45f4155bada1f33ff9fa8127c9145bfc0cf96f9e148466b6cf3b",
"ni__defs_8h.html#ad17d6e18a9823cd16642c7f4aebdd247aafa3986ac2d93a2689563fea981b7a22",
"ni__device__api_8h.html#a254d28792d6935127016ebdf86a9debd",
"ni__device__api_8h.html#a8266e576d66a91f13859d7428e5422fd",
"ni__device__api_8h.html#adedffd401326d5657bdaf040510b3fce",
"ni__device__api__priv_8h.html#abe6e70c687bb721cdd632a6e1a00bd47",
"ni__device__test_8h.html#afddfc0468a0fb0d80c116b5e16b9be17",
"ni__nvme_8h.html#a57804cf4e06ea8f14d069f646ea79ff6",
"ni__rsrc__api_8h.html#a7a1bc697649fdd428cb969c6c0f9aba8",
"struct___n_e_t_i_n_t___l_i_b_x_c_o_d_e_r___a_p_i___f_u_n_c_t_i_o_n___l_i_s_t.html#aa3090ebd4dbcbbf923f3988c45817e08",
"struct__ni__device__info.html#a7c83c99b4f3f7039be4f7e92f610c179",
"struct__ni__encoder__config__t.html#adbc19de5f7074cad8c8a957daf22c8b2",
"struct__ni__h265__sps__t.html#ac045cc86ac8444ad7a49709857375b83",
"struct__ni__nvme__id__power__state.html#ae71bb513e7981aeacf87ec6a26e96f5d",
"struct__ni__session__context.html#a130069ab4d62f1cfaf17781e361f9a3f",
"struct__ni__t408__config__t.html#aa8a865dc5d4a14ca3ca0dcd73f7b8613",
"structdec__recv__param.html#ab9fcb0ebe4cd2a0701aa94e4d1542a1f"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';