var struct__ni__network__layer__params__t =
[
    [ "affine", "struct__ni__network__layer__params__t.html#a9da27806a3c55112684d92cb63e01602", null ],
    [ "data_format", "struct__ni__network__layer__params__t.html#a091b935c33d38ff96315731cc66c1ddb", null ],
    [ "dfp", "struct__ni__network__layer__params__t.html#a3ce603bf93026de1bc9319afa0843b0e", null ],
    [ "fixed_point_pos", "struct__ni__network__layer__params__t.html#a8f258cd9d5dcdf35b658d3327c05e05a", null ],
    [ "memory_type", "struct__ni__network__layer__params__t.html#ad1557be47b90ae31d12b9f443224b738", null ],
    [ "num_of_dims", "struct__ni__network__layer__params__t.html#a077223ab5da4f83f266219b93f894ab6", null ],
    [ "quant_data", "struct__ni__network__layer__params__t.html#abe35d7599436a37d625a51862b8ce8ce", null ],
    [ "quant_format", "struct__ni__network__layer__params__t.html#a8ccab6857970d9fba1ab46bc6dd48bee", null ],
    [ "scale", "struct__ni__network__layer__params__t.html#a1d28dec57cce925ad92342891bd71e7c", null ],
    [ "sizes", "struct__ni__network__layer__params__t.html#a5ebe35090f5bb13d6f2273618b88365b", null ],
    [ "zeroPoint", "struct__ni__network__layer__params__t.html#a26d3273f06bea34523b4a4a27f0bec54", null ]
];