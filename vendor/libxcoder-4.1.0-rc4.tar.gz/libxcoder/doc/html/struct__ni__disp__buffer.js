var struct__ni__disp__buffer =
[
    [ "bar", "struct__ni__disp__buffer.html#a2df8914184cddeed49ac0b633472d973", null ],
    [ "data", "struct__ni__disp__buffer.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "fd", "struct__ni__disp__buffer.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "len", "struct__ni__disp__buffer.html#af2e72f8a5bf4bcdb77566c2936d5f13d", null ],
    [ "mmap_data", "struct__ni__disp__buffer.html#adcf5ce0b11c1a70c8bfad1451b7224ff", null ]
];