var ni__getopt_8c =
[
    [ "getopt", "ni__getopt_8c.html#a2a1e886d6bd661b8d715948b042a06cc", null ],
    [ "getopt_long", "ni__getopt_8c.html#ae360ffe9254dc9dbfce0e87f9e90bdc4", null ],
    [ "optarg", "ni__getopt_8c.html#adb50a0eab9fed92fc3bfc7dfa4f2c410", null ],
    [ "opterr", "ni__getopt_8c.html#ae30f05ee1e2e5652f174a35c7875d25e", null ],
    [ "optind", "ni__getopt_8c.html#ad5e1c16213bbee2d5e8cc363309f418c", null ],
    [ "optopt", "ni__getopt_8c.html#a475b8db98445da73e5f62a1ef6324b95", null ]
];