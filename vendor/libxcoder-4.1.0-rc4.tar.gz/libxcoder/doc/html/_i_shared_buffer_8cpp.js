var _i_shared_buffer_8cpp =
[
    [ "BpSharedBuffer", "class_bp_shared_buffer.html", "class_bp_shared_buffer" ],
    [ "LOG_TAG", "_i_shared_buffer_8cpp.html#a7ce0df38eb467e59f209470c8f5ac4e6", null ],
    [ "GET_BUFFER", "_i_shared_buffer_8cpp.html#a06fc87d81c62e9abb8790b6e5713c55ba38718ea169e678ff631ea9c1558f3688", null ],
    [ "GET_FD", "_i_shared_buffer_8cpp.html#a06fc87d81c62e9abb8790b6e5713c55bad771feac278dcfc8974e7280ef7e3887", null ],
    [ "SET_FD", "_i_shared_buffer_8cpp.html#a06fc87d81c62e9abb8790b6e5713c55babe3313a2dd1e7049ad4c6dae7712d44b", null ],
    [ "IMPLEMENT_META_INTERFACE", "_i_shared_buffer_8cpp.html#a910977527a5401ebc3206a58447a9c3b", null ]
];