---
name: Regression Issue
about: Use this template for reporting a regression
---

## System information
- Impacted GPU platform:
- Host machine if it's descreted card:
- Good libva/libva-utils/gmmlib/media-driver version?
- Bad libva/libva-utils/gmmlib/media-driver version?

## Issue behavior
### Describe the current behavior

### Describe the expected behavior
