---
name: Feature Request
about: Use this template for raising a feature request
---

## System information
- GPU platform enabling for new feature:
- Host machine if it's descreted card:
- libva/libva-utils/gmmlib/media-driver version you are using?
- Are you willing to contribute it?(Yes/No)

## Feature Information
### Describe the feature and expected behavior

### Customer usage and impact for this feature
