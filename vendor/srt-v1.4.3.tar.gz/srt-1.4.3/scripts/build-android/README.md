## Scripts for building SRT for Android

**NOTE:** The scripts have been moved from `docs/Android/` folder. Updating the paths might be required.

See [Building SRT for Android](../../docs/build/build-android.md) for the instructions.
